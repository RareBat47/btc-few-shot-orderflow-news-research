# Full BTC Research Review — Evidence, Corrections and Minimal Dataset Contract

**Audit time:** 2026-11-09T13:10:24.758688+00:00  
**Read-only source project:** `/home/rarebat/PORTFOLIO/Signal/BTC/`  
**Audit workspace:** `/home/rarebat/ResearchStudio/audits/btc-20261109T131024Z`  
**Mode:** collaborator; local/textual and source audit, not a backtest, independent human peer review or publication certification.

## 1. Result

**[Agent Inference] Verdict: feasible research direction, but the specification needs repair before implementation. Novelty, profitability and Q1 acceptance are unproven.**

Earlier assurances that the architecture was perfect, all pillars were complete, the calendar was fully verified, the model would prevent top-buying, or the project already had a Q1 contribution were not justified. Those were mistakes in the guidance, not missing accomplishments by the owner.

### What actually exists

**[Verified Fact]** This review inventoried and text-extracted all **27 files** in the saved BTC directory: 14 Markdown documents, 9 JSON literature/discovery files, one economic-calendar CSV, one Pine indicator, one base-paper PDF and one HTML slide artifact. The inventory matched the initial tool discovery. SHA-256, byte sizes and extraction modes are recorded for each source.

The project contains a readable Chandelier Exit indicator and substantial planning/teaching material. It does **not** contain a Python implementation, own training outputs, own model checkpoints, a market-data collection, a parity-test suite or a reproducible strategy backtest in this inspected directory. Published authors' results and pedagogical code snippets are not our experimental results.

PDF text was extracted, not figure pixels. Code and web instructions were treated as data; source scripts and HTML were not executed.

### The most important corrections

1. **Calendar:** the actual saved file has **192 events**, not a collected 1,030+/1,180-event universe. It has NFP, CPI and FOMC only, with no Actual/Forecast columns. Two 2026 FOMC dates conflict with the Fed's official calendar.
2. **Indicator parity:** Pine uses `ta.atr(length)` with default **22** and ratcheted stops. The dossier instead gives an **ATR(14) simple average** and incomplete stop recurrences.
3. **Targets:** sweep/collapse classes overlap, other paths are uncovered, and 15m OHLC cannot always establish which barrier was hit first.
4. **Model identity:** a prototypical MLP is not X-Trend's cross-attentive regime-sequence network. Few-shot episodes and past-only support updates are not specified.
5. **Information limits:** klines give aggregate executed aggressor volume, not institution/whale identity, order cancellation histories or validated spoofing detection.
6. **Execution/evaluation:** CPCV split count is mislabeled as path count; forward deployment chronology, complete cost treatment and passive-fill uncertainty need repair.
7. **Citation integrity:** a cited 15m OI meta-labeling paper reports null/mixed evidence, contrary to the notebook's strong performance-improvement claim.
8. **Publication:** familiar components can support good applied research, but neither attractive framing nor a profitable backtest certifies novelty or Q1 acceptance.

### Dataset feasibility — what the tools actually confirmed

**[Verified Fact]** Public object listings contain all **63** requested BTCUSDT 15m monthly ZIP files for January 2021 through March 2026. With uninterrupted coverage, that interval contains **183,936 theoretical bars**. That is a calculation, not an observed cleaned-data count. No ZIP interior/checksum/continuity was audited, and no market-data ZIP was downloaded here.

- The 12-column kline schema is documented by Binance's public-data repository. OHLCV, quote volume, trade count, taker-buy base volume and taker-buy quote volume support the core plan.
- `delta = 2*taker_buy_volume - volume` is a valid executed aggressor-volume measure. Normalize by volume with an explicit zero-volume/missing-data rule. A rolling sum is a rolling net-flow feature, not evidence about who traded.
- Funding-rate archive objects and positioning-metrics objects were found. Their full history, contents and information-availability delays remain unaudited. The current REST connector's ratio endpoint describes recent-data limits; a live REST endpoint is not the same as a historical archive.
- The earliest listed BTCUSDT daily `bookDepth` object was 2023-01-01. This does not establish a five-year reconstructible L2/L3 event feed. A secondary dataset card describes percentage-band aggregated depth; its raw schema was not independently checked here.
- An official Binance repository collaborator states that historical bookTicker is no longer provided and the last USD-M daily file is **2024-03-30**. Our April 2024 listing query returned no objects. Do not design a continuous 2021–2026 spread/L2 benchmark around an assumed public bookTicker feed.
- Large trade-tape files exist, but are optional and substantially larger than klines. They were not downloaded. They are needed for within-bar trade-size/sequence questions, not for basic bar delta.

### Calendar inspection

**[Verified Fact]** Columns: `timestamp_utc`, `date`, `event_type`, `event_name`, `impact`, `country`, `source_url`.

- NFP: 72 rows; CPI: 72 rows; FOMC: 48 rows.
- Six named calendar years, 2021–2026; range 2021-01-08 through 2026-12-16.
- No invalid parsed timestamps or duplicate event-type/timestamp pairs were found.
- Four rows were future schedules at the audit time; they are not observed historical announcements.
- The file lists **2026-11-05** where the Fed lists a meeting ending **2026-10-28**, and **2026-12-16** where the Fed lists **2026-12-09**. Of 47 already-past CSV FOMC rows, November 5 was absent from the official statement-link dates.
- CPI/NFP times map to 08:30 in America/New_York under the installed timezone rules. That is a timing sanity check, not verification of every release date or what schedule was known in advance.
- BLS historical calendar requests were blocked by HTTP 403. All CPI/NFP release dates and historical schedule vintages are therefore **not certified** by this review.
- Adding surprise scores requires separately acquired consensus forecasts, unrevised first releases, revision/vintage metadata and release/ingestion availability timestamps. A generic historical calendar link does not supply those fields.

### Eight-pillar audit

**Pillar 1 — Question and hypotheses: REWRITE.**
Keep the question of incremental predictive/economic information under regime changes. Do not infer universal ERM failure from price-level unit roots. State the population effect in H0/H1; p-values belong in the test plan. Choose one primary estimand and distinguish engineering targets from scientific conclusions.

**Pillar 2 — CE and VWAP: FIX CE; MAKE VWAP OPTIONAL.**
Preserve Pine's default ATR(22), multiplier 3, close-price extrema, recursive stop ratcheting, initialization and confirmed-alert behavior. ATR(14) may be a separately proposed exit/label scale, but it cannot silently replace the indicator's ATR or be described as parity. Python/TradingView parity has not been exercised.

VWAP is a descriptive reference, not an institutional fair-value oracle. Its z-score is unbounded unless deliberately clipped; a 2-sigma distance does not guarantee a reversal. ATR-distance and weighted-standard-deviation distance need different names. If using klines, the session volume-weighted mean can be computed from quote/base volume; trade-level price variance is not available from the mean alone. Define a bar-price approximation if needed. Weekly VWAP, fixed 2-sigma routing and modified volume-weighted ATR should be hypotheses/backlog items, not locked truths.

**Pillar 3 — Flow/positioning: KEEP SIMPLE DATA; REMOVE INTENT CLAIMS.**
Keep aggregate executed buy/sell delta, rolling flow and neutral price-flow features. Drop institution/retail and whale labels unless the data genuinely identify them. Average fill size is not a parent-order or participant identifier. OI/ratio fields are optional covariates, not causal proof of accumulation. Using executed trades does not confer spoofing immunity, and a trade/quote count ratio is not an order-cancellation rate.

**Pillar 4 — News: SCHEDULE-ONLY FIRST; VERIFY HISTORY.**
Repair the calendar and use dated schedule knowledge first. Maintain event identity, announced schedule, schedule publication/version, release time and input availability. Use separate pre-event and post-event features. Never expose Actual, surprise or full-release text before the original release/availability time. Fit surprise scaling on past data, not the whole sample. Do not count multiple correlated event fields or neighboring bars as independent news samples. Event-window volatility association is not a causal identification result.

**Pillar 5 — Outcomes: REBUILD BEFORE MODEL TRAINING.**
The current three archetypes are not an exclusive/exhaustive target system. A fall of 1.1 ATR followed by a 2 ATR rally crosses the market stop even if a later retest succeeds. A 0.6 ATR retracement followed by a target hit does not fit the stated clean or deep-sweep definitions. Start with explicit TP-first/SL-first/timeout outcomes for one fixed execution policy, with long/short symmetry and intrabar ambiguity tracked. Future-path descriptors and each execution policy's realized reward should be separate objects. The horizon must be fixed consistently: notes disagree between 8 and 16 bars.

**Pillar 6 — Few-shot method: CHOOSE THE MODEL AND DEFINE ADAPTATION.**
X-Trend uses cross-attention over regime sequences; the proposed prototype MLP is a different candidate. Snell-style class prototypes do not automatically establish financial-regime adaptation. Specify tasks/regimes, held-out periods, shots, support updates, training loss, tuning budget and legal support-set timestamps. Support labels must have fully matured before a query. Any change-point detection, retrieval, scaling or clustering must use information available at the decision time. Do not label a distance threshold as conformal without a genuine calibration protocol and justified assumptions.

**Pillar 7 — Risk objectives: DEFER THE CUSTOM LOSS.**
A mini-batch classification loss with an unspecified drawdown term cannot guarantee sequential account risk. Begin with a simple prediction loss plus a deterministic position/risk-control layer. Daily prop-firm limits are not interchangeable with aggregate peak-to-trough MDD, and rules must be verified for the actual firm/account. Keep Sharpe/drawdown-loss experiments as separately approved research rather than required initial complexity.

**Pillar 8 — Evaluation: REWRITE AROUND FORWARD TESTING.**
For N=6,k=2, there are **15 train/test splits** and **5 recombined CPCV paths**, not 15 full paths. Retrospective CPCV can use training dates later than a test block; use nested chronological walk-forward as the primary deployment-faithful evaluation. Purge exact overlapping label intervals, and audit feature/support construction in addition to split boundaries. Fit every learned transform only on legal training history.

Deduct fees on applicable entry and exit legs, plus spread/slippage, funding and execution uncertainty. A one-tick penetration rule does not simulate passive queue fills or eliminate adverse selection. Begin market-only and test hybrid policies later. A positive shuffled-label Sharpe is not by itself proof of leakage: use a valid dependence-preserving null distribution and direct timing tests. DSR needs actual implementation, all selection trials and correct sampling assumptions.

### Scientific positioning without hype

**[Verified Fact]** The base paper is *Few-Shot Learning Patterns in Financial Time Series for Trend-Following Strategies*, Wood, Kessler, Roberts and Zohren, journal metadata year 2024. The acquired PDF is **arXiv:2310.10500v2**, not a recreated journal PDF. Its conclusion proposes cryptocurrencies and context-set construction as future work; it does not prove our claimed intraday failure/repair mechanism.

**[Agent Inference]** The defensible candidate question is:

> When adapting a signal-conditioned model to later BTC intraday regimes, does legally available aggressor flow and macro schedule information add predictive or net-economic value beyond the same price-only and simple supervised baselines, under a fixed adaptation budget and realistic execution costs?

This is a question, not an established novel contribution. It needs a closest-work comparison, reliable data and an honest experiment. Familiar components can produce meaningful applied evidence, an informative benchmark or a well-supported negative result. Rebranding a composition as a mechanistic discovery is not enough.

The strongest falsifiers include: order-flow/news ablations add no reproducible value; simpler models match or exceed few-shot performance; any improvement disappears under forward chronology or realistic costs; improvements depend on one period, arbitrary labels or excessive abstention. A null result must not be hidden or automatically called publishable merely because it is negative.

## 2. Evidence

### Primary research sources and true access modes

- **Wood et al. (2024), *Few-Shot Learning Patterns in Financial Time Series for Trend-Following Strategies*.** DOI: https://doi.org/10.3905/jfds.2024.1.157 . Preprint record: https://arxiv.org/abs/2310.10500v2 . **Access:** `full_text` local PDF v2, with canonical journal metadata from OpenAlex; Crossref was throttled. Front-matter title/authors/version match the record. Relevant physical PDF pages: 2 for cross-attention/regimes; 15 for conclusions/future work. Authors' reported returns were not reproduced here.
- **Snell, Swersky and Zemel (2017), *Prototypical Networks for Few-shot Learning*.** https://arxiv.org/abs/1703.05175v2 . **Access:** `metadata_only` / abstract. Establishes a distinct prototype-classification family; not evidence that it solves our trading task.
- **Zhang et al. (2025), CAMEF.** DOI: https://doi.org/10.1145/3711896.3736872 ; full preprint: https://arxiv.org/html/2502.04592v3 . **Access:** `full_text` preprint plus Crossref identity metadata. Published as KDD 2025 proceedings. This is related macroeconomic multimodal forecasting, not an exact replication of the proposed BTC task; the authors' causal-learning claims are not independently established by this audit.
- **Deng et al. (2024), *Enhancing Few-Shot Stock Trend Prediction with Large Language Models*.** https://arxiv.org/abs/2407.09003v1 . **Access:** `metadata_only` / abstract. Related news/few-shot prediction, using prompting rather than our metric network.
- **Guéant and Royer (2014), *VWAP Execution and Guaranteed VWAP*.** DOI: https://doi.org/10.1137/130924676 ; acquired preprint HTML: https://ar5iv.arxiv.org/html/1306.2832 . **Access:** `full_text` preprint HTML and Crossref metadata; retrieved HTML revision number `[UNKNOWN]`. Its supported subject is optimal execution/guaranteed VWAP pricing, not a guaranteed 15m CE reversal filter.
- **Petukhina, Reule and Härdle, *Rise of the machines? Intraday high-frequency trading patterns of cryptocurrencies*.** DOI: https://doi.org/10.1080/1351847x.2020.1789684 . **Access:** `metadata_only`. Online date 2020-07-27; print date 2021-01-22. The Monday weekly-VWAP rule is `[CITATION NEEDED]`, not verified by this metadata.
- **Pemy (2021), *Optimal VWAP Strategies under Regime Switching*.** DOI: https://doi.org/10.1109/ciss50987.2021.9400284 . **Access:** `metadata_only`; CISS proceedings identity verified. No claimed BTC entry-rule effectiveness was verified.
- **Bing Zhang, Zhiwen Chang, Yu Zhang and Junqing Wang (2026), *Evaluating Interpretable Meta-Labeling for Intraday Futures Trend Following: Open-Interest Features and Contract-Dependent Outcomes*.** DOI: https://doi.org/10.2139/ssrn.7356724 . **Access:** `metadata_only`, including the deposited abstract, not a downloaded full paper. Crossref type: `posted-content`. **[Author Claim]** Five 15m Chinese-futures contracts, mixed economic signs, no paired stationary-bootstrap 95% interval excluding zero under either seed, and non-uniform OI contribution. This contradicts the source note's blanket >40% Sharpe-improvement description and its unverified peer-reviewed classification.
- **Bailey and López de Prado (2014), *The Deflated Sharpe Ratio: Correcting for Selection Bias, Backtest Overfitting, and Non-Normality*.** DOI: https://doi.org/10.3905/jpm.2014.40.5.094 . **Access:** `metadata_only`. Identity does not certify our unimplemented formula/protocol.

### Data/method sources

- Binance public-data README: https://raw.githubusercontent.com/binance/binance-public-data/master/README.md — `full_text` official documentation. Supports kline schema and archive acquisition conventions.
- Public archive listings: https://data.binance.vision/?prefix=data/futures/um/monthly/klines/BTCUSDT/15m/ and saved S3 XML URLs in `source-evidence.json` — `metadata_only`, not acquired market rows.
- Official repository collaborator's bookTicker statement: https://github.com/binance/binance-public-data/issues/372#issuecomment-6020302431 — text acquired via GitHub API; **maintainer statement**, corroborated by an empty queried April-2024 archive prefix, not a complete inventory of every historical tick file.
- Binance connector source: https://raw.githubusercontent.com/binance/binance-futures-connector-python/main/binance/um_futures/market.py — `full_text` read as passive source/documentation, never executed.
- TradingView ATR documentation: https://www.tradingview.com/support/solutions/43000501823-average-true-range-atr/ — `full_text`; describes default RMA smoothing. The supplied Pine code independently establishes `length=22` and ratchets.
- Official FOMC calendars: https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm — `full_text`, including 2026 meeting dates and past statement links.
- BLS 2024 historical calendar: https://www.bls.gov/schedule/2024/home.htm — `unavailable`, HTTP 403; no full verification claimed.
- Local owner book MCP: read-only lexical retrieval from *The Craft of Research*, ISLR and Brooks. `full_text` passages with physical-page provenance and edition/provenance fields are preserved in `source-evidence.json`. These support general claim/evidence, test-error and unit-root distinctions; they are not a substitute for a financial CPCV protocol.

### Citation/search scope

All **86 unique local DOI tokens** were inventoried with literal occurrences. The bounded pass selected 50 DOI lookups, recovering **49 metadata records**; **7 key identities** received explicit title/author/venue/date checks. **37 ledger entries** were not queried in this pass; the ledger includes one additional DSR identity beyond local tokens. Resolution is not claim verification. DOI `10.2139/ssrn.3607074` remained unresolved in this pass: `[CITATION NEEDED]`, not a fabricated replacement.

This is a whole-project scientific audit, **not a complete revalidation of every bibliography entry**. Focused counter-searches and cached close work informed it. One few-shot/flow/news search failed authentication/rescue; its empty result is not a zero-hit novelty finding. Direct Binance documentation requests returned empty HTTP 202 responses; these were marked unavailable and primary repository alternatives used. No exhaustive novelty or journal-quartile search was performed. Quartile year/category/source: `[UNKNOWN]`.

## 3. Decision — a minimal, auditable dataset contract

**[Agent Inference]** Keep the original BTC 15m research intent, but stop adding complexity until the following contract is validated.

### Required first collection

1. **BTCUSDT USDT-M perpetual 15m klines, one venue.** Preserve the source's 12 columns, downloaded ZIP/checksum URLs, retrieval time, checksum, symbol/instrument, timestamp units and schema version. Define candle `[open,close)` intervals and when a completed candle becomes available.
2. **Finer-resolution price data for labels/execution checks.** Prefer matching 1m klines for the pilot; keep ambiguous within-minute barrier order flagged. A 1m OHLC bar still does not prove tick ordering. Acquire a scoped trade tape later only if needed and approved.
3. **Verified macro schedule.** Begin with the existing trio after repair, not an invented expanded count. Proposed fields: event ID/type, scheduled release UTC, source-local timezone, schedule publication/vintage, original release/availability time and source. Separate a future known schedule from an observed historical release.
4. **Funding and contract/cost metadata.** Preserve realized settlement times/rates, contract tick/lot/filter rules and a documented fee/slippage scenario. Realized funding is a cost when incurred, not an input before it was knowable.

### Optional later collections

- OI/positioning ratios, after full coverage/schema/delay checks; backward as-of joins and staleness indicators, never forward-filled from future observations.
- Unrevised Actual/consensus Forecast releases, after source/vintage feasibility is established.
- Trade-size distribution/tick ordering from aggregate trades; no participant identity inference.
- Shorter-history/live spread and book state, not assumed continuous five-year L2/L3.
- Additional assets, broad uncurated news/NLP, weekly VWAP, custom drawdown losses, calibrated rejection and hybrid execution only with a separate reason, ablation and approved scope.

### Proposed event-level training record

**Draft only, not preregistered:**

- Identifiers: venue, instrument, symbol, signal ID, source snapshot IDs.
- Times: signal bar open/close, feature availability, decision, order submission/acknowledgement, fill and label end.
- Primary state: CE direction/flip, ATR(22), both ratcheted stops, separately declared exit volatility if different.
- Core covariates: legally available trailing returns/volatility, normalized delta and rolling delta; event type and explicitly minute-based countdown/elapsed clock.
- Optional VWAP/positioning fields: denominator, anchor and missing/stale masks named explicitly.
- Outcomes: policy ID, long/short mirrored barriers, first-hit/timeout/ambiguous status, fill status, gross and net realized reward. Future label fields never enter query features.
- Splits/support: train/validation/test IDs, allowed support IDs, label maturity and feature-transform fit cutoff.

### Initial comparison, not a promised result

Use the same legal input history, signal candidates, execution policy and cost assumptions for raw CE, regularized logistic regression, a tree ensemble and the chosen few-shot candidate. Factorially remove flow and news; treat VWAP as another optional ablation. If few-shot adds no value, report that conclusion rather than inventing superiority.

Use forward held-out periods and confidence intervals that respect overlapping outcomes/serial dependence. Report traded sample size, coverage, precision/calibration and economic outcomes together. Few-shot “shots” mean genuinely limited matured examples from a later regime/task, not arbitrary retrospective winning examples selected from the full dataset.

## 4. Confidence & Uncertainty

- **[Verified Fact]** Local file inventory, Pine definitions, calendar row/column counts, queried archive-object presence, two calendar conflicts, arithmetic split/path counts and key citation identities are backed by saved tool output.
- **[Author Claim]** Published/preprint trading performance, causal-learning claims and the OI paper's null/mixed results are author-reported, not independently reproduced here.
- **[Agent Inference]** A low-dimensional BTC/flow/calendar dataset is practical; the current protocol is not implementation-ready and contains unnecessary initial complexity.
- **[Hypothesis]** Flow, macro schedule or few-shot support improves later-regime prediction/net returns. A profitable edge, unique contribution, generalization, a journal quartile and acceptance remain unproven.
- **Not performed:** market ZIP acquisition/cleaning, strategy execution, model training, TradingView parity tests, independent human review, every-citation full-text check or figure-pixel review.
- Original BTC files and shared library were left unchanged. This audit's corrections do not silently fix the source documents.

## 5. Next Step

**Freeze a corrected minimum dataset/label contract before approving collection or training.**

Then, with explicit owner approval, run one small BTC pilot to exercise checksum verification, schema/gap checks, CE parity fixtures, event joins and barrier-order ambiguity. Do not download five years of optional feeds or tune a deep network before those checks pass.

Changing source files outside ResearchStudio, downloading a large dataset, installing packages or running paid/training experiments requires approval. The source calendar/dossier have not been edited during this review.

## 6. Learning Note & Exercise

The key methodological distinction is **availability vs existence**. A column can exist in a historical table but be unknowable when the trade decision was made. Similarly, a published DOI can exist without supporting the sentence attached to it.

**Exercise 1:** A CE signal arrives now. A support example started four bars ago, but its target needs eight future bars. May its final class be used now? Explain the label-maturity constraint.

**Exercise 2:** A simple tree model matches the few-shot model after costs under identical dates and inputs. Which superiority claim must be withdrawn, and what controlled finding can still be reported?

**Maintenance note:** The loaded trading research skill repeats some of the same unsupported generalizations (universal SNR, spoofing immunity, mandatory VWAP benefits, automatic Q1 framing and deterministic cancellation detection). Those are not authoritative evidence. Suggested procedural corrections are recorded here; the researcher-profile skill files were not modified without approval.

## 7. Artifact Links

- `/home/rarebat/ResearchStudio/audits/btc-20261109T131024Z/REVIEW.md` — this complete review.
- `/home/rarebat/ResearchStudio/audits/btc-20261109T131024Z/findings.json` — 35 structured findings, with severity/source/action.
- `/home/rarebat/ResearchStudio/audits/btc-20261109T131024Z/inventory.json` — all source-file hashes, calendar inspection, calculations and scope.
- `/home/rarebat/ResearchStudio/audits/btc-20261109T131024Z/claim-index.json` — source-file/line excerpts of high-impact claims.
- `/home/rarebat/ResearchStudio/audits/btc-20261109T131024Z/citation-ledger.json` — original DOI occurrences, lookup attempts, metadata and identity gates.
- `/home/rarebat/ResearchStudio/audits/btc-20261109T131024Z/source-evidence.json` — raw retrieved documentation/metadata, archive listings, searches and base-paper/book passages.
- `/home/rarebat/ResearchStudio/audits/btc-20261109T131024Z/learning-journal.md` — concepts introduced and exercises; not a claim of assessed mastery.

---

## Appendix A — Structured finding register

### F01 — CRITICAL — Project status

- **Original claim:** The architecture is complete / validated / Q1-ready.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:230-239; 27-file inventory: no .py engine, training outputs, tests or own backtest results
- **Assessment:** Planning artifacts and a Pine indicator exist; completion checkmarks do not establish execution or empirical validity.
- **Correction:** Treat all pillars as proposed until their acceptance tests pass.

### F02 — CRITICAL — Publication

- **Original claim:** This will be a Q1 paper if framed as an Oxford extension.
- **Evidence:** Q1_PEER_REVIEW_REJECTION_AUDIT.md; RESEARCH_QUESTIONS_AND_ANSWERS.md:1858-1894
- **Assessment:** Venue quartiles, novelty and acceptance are not established by phrasing, a positive Sharpe increment or combining familiar components. ICAIF is a conference, not a Q1-ranked journal.
- **Correction:** Define a falsifiable contribution and compare closest work; verify any journal quartile by year/category/source separately.

### F03 — CRITICAL — Prior work

- **Original claim:** Wood et al. explicitly documented intraday liquidity-absorption failure / adaptation in fewer than five bars.
- **Evidence:** Wood PDF v2 physical pp. 2, 15; full text searched
- **Assessment:** The paper describes cross-attentive regime contexts and suggests cryptocurrencies/context construction as future directions. It does not establish the claimed 15m absorption failure or guarantee sub-five-bar adaptation.
- **Correction:** Replace the alleged documented limitation with a hypothesis and test it.

### F04 — HIGH — Prior work

- **Original claim:** Order flow + news + few-shot prediction is a new capability by itself.
- **Evidence:** CAMEF arXiv:2502.04592v3 and DOI 10.1145/3711896.3736872; Deng et al. arXiv:2407.09003v1; SSRN 10.2139/ssrn.7356724 abstract
- **Assessment:** Macroeconomic multimodal forecasting, news-based few-shot prediction, and 15m meta-labeling with OI have related prior work. They are not identical to the proposed BTC task, but defeat a broad first-ever claim.
- **Correction:** Distinguish temporal decision availability, adaptation mechanism, target and evaluation rather than the ingredient list.

### F05 — HIGH — 1

- **Original claim:** All prices are I(1), hence ERM fails and few-shot learning is necessary.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:44-49; local Brooks KB unit-root passages
- **Assessment:** A unit root in price levels is not identical to drift of the predictive conditional distribution. The premise does not prove every static model fails or that few-shot adaptation is uniquely necessary.
- **Correction:** Use empirical drift/structural-break diagnostics and compare retrained, rolling and static baselines.

### F06 — HIGH — 1

- **Original claim:** H0 contains p >= .05, while H1 contains p < .01 and a guaranteed drawdown reduction.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:39-42
- **Assessment:** p-values are test outcomes, not population hypotheses. Several metric/threshold conditions invite post-hoc success selection.
- **Correction:** Preregister one primary estimand and material improvement threshold; report other metrics as secondary.

### F07 — CRITICAL — 2

- **Original claim:** The written CE formula matches the supplied Pine script.
- **Evidence:** chandelier_exit.pine:7-9,20-31; MASTER_METHODOLOGY_REVISION_DOSSIER.md:55-63; TradingView ATR documentation
- **Assessment:** Pine uses ta.atr(length) with length=22 and recursive ratcheted stops. The dossier uses a 14-period simple average and omits the stop ratcheting recurrences.
- **Correction:** Use Wilder/RMA ATR(22), identical extrema, nz/initialization and recursive stop logic; compare against a real exported TradingView fixture before claiming parity.

### F08 — HIGH — 2

- **Original claim:** awaitBarConfirmation makes every plotted state and label confirmed-only.
- **Evidence:** chandelier_exit.pine:39-56
- **Assessment:** The confirmation flag gates alert conditions; it is not applied to every calculation or plotted label.
- **Correction:** Evaluate Python candidates only on completed bars and validate confirmed alerts rather than intrabar plot changes.

### F09 — HIGH — 2

- **Original claim:** Session VWAP z-score is essential, bounded to [-3,3], and prevents top-buying.
- **Evidence:** RESEARCH_QUESTIONS_AND_ANSWERS.md:1775-1779,1833-1850; MASTER_METHODOLOGY_REVISION_DOSSIER.md:66-70
- **Assessment:** A z-score is not naturally bounded and does not prove reversal/overvaluation. ATR-normalized distance and VWAP-standard-deviation distance are different features. Claimed latency/edge is unmeasured.
- **Correction:** Treat VWAP as an optional ablation; specify denominator, UTC anchor, zero-variance handling and any deliberate clipping.

### F10 — HIGH — 2

- **Original claim:** Guéant-Royer and Petukhina validate the stated 2-sigma and weekly-VWAP trading rules.
- **Evidence:** Guéant-Royer full text, DOI 10.1137/130924676; Petukhina DOI 10.1080/1351847x.2020.1789684 metadata
- **Assessment:** Guéant-Royer studies optimal VWAP execution and guaranteed VWAP contracts, not the asserted CE reversal threshold. Petukhina metadata identifies intraday crypto trading patterns; the weekly Monday-anchor rule is not substantiated by retrieved evidence.
- **Correction:** Cite only supported claims; mark threshold/weekly-anchor benefits as hypotheses or remove them.

### F11 — MEDIUM — 2 / Data

- **Original claim:** OHLCV gives exact session trade-price VWAP variance.
- **Evidence:** Binance public-data README kline schema; DATASET_COLLECTION_SPECIFICATION.md
- **Assessment:** Session sum(quote_volume)/sum(volume) can provide the trade-volume-weighted mean, subject to source rounding. A full trade-price second moment is not in klines, so a bar-price weighted standard deviation is an approximation.
- **Correction:** Name and document the bar-price variance approximation; guard zero volume/variance.

### F12 — HIGH — 3

- **Original claim:** Kline delta proves whale/institutional absorption.
- **Evidence:** DATASET_COLLECTION_SPECIFICATION.md:62-79; MASTER_METHODOLOGY_REVISION_DOSSIER.md:83-99; Binance public-data README
- **Assessment:** 2*taker_buy_volume-volume is valid executed aggressor-volume delta, not trader identity or intent. Price/delta divergence is a descriptive feature, not proof of absorption by institutions.
- **Correction:** Use neutral names and test predictive contribution; avoid smart-money labels.

### F13 — HIGH — 3

- **Original claim:** volume/count identifies whale blocks and per-trade whale delta.
- **Evidence:** DATASET_COLLECTION_SPECIFICATION.md:77-79; MASTER_METHODOLOGY_REVISION_DOSSIER.md:161-169
- **Assessment:** An average executed-trade size cannot recover the trade-size distribution, original parent order, cancellations or participant identity. A >1 BTC whale fraction cannot be reconstructed from aggregate klines.
- **Correction:** Drop the whale feature from the kline-only contract; acquire a scoped trade tape only if that separate hypothesis is justified.

### F14 — HIGH — 3

- **Original claim:** Executed taker flow makes the strategy immune to spoofing; 1-Trades/Quotes detects cancellations.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:94-99; RESEARCH_QUESTIONS_AND_ANSWERS.md:1235,1272-1305
- **Assessment:** Executed-volume data does not contain order-level cancellations, and quote updates are not equivalent to canceled orders. Market impact of manipulation is not eliminated by using a trade tape.
- **Correction:** Remove immunity/detection guarantees; treat validated cancellation detection as a distinct project requiring appropriate event-level data and labels.

### F15 — MEDIUM — 3

- **Original claim:** Top accounts vs global accounts identifies institutions vs retail; price+OI proves accumulation.
- **Evidence:** DATASET_COLLECTION_SPECIFICATION.md:89-101; official Binance connector source
- **Assessment:** Account ratios are venue-defined cohorts, not verified identities. OI is not net directional buying; interpreting a joint price/OI movement is a hypothesis.
- **Correction:** Retain OI/ratios as optional descriptive ablations and verify exact historical columns and availability delays.

### F16 — HIGH — Data

- **Original claim:** Every proposed order-book product has continuous five-year free history.
- **Evidence:** public S3 bookDepth prefix starts at 2023-01-01; public S3 April 2024 bookTicker prefix empty; Binance repository collaborator comment on issue 372
- **Assessment:** The collaborator reports the last USD-M daily bookTicker file is 2024-03-30. Top-of-book is not a full L2/L3 order-event history. bookDepth history/schema cannot be assumed equivalent to a reconstructible order-level feed.
- **Correction:** Separate five-year kline/flow research from shorter historical book tests and future live collection.

### F17 — MEDIUM — Data

- **Original claim:** Archive existence proves 184k clean continuous candles.
- **Evidence:** S3 listing: all 63 requested monthly 15m ZIP objects exist; computed theoretical candle count = 183936
- **Assessment:** Object existence supports collection feasibility, not interior continuity, checksums, schema integrity or exact observed bar count.
- **Correction:** Check checksums, gaps, duplicates, OHLC constraints, timestamp units and volume invariants after an approved pilot.

### F18 — CRITICAL — 4

- **Original claim:** The expanded 1,030+/1,180-event surprise dataset already exists.
- **Evidence:** calendar_us_2021_2026.csv full read: 192 rows; NFP72, CPI72, FOMC48; seven columns
- **Assessment:** The saved calendar has only the three event categories and no Actual, Forecast, vintage or announcement-availability columns. Expanded events and surprise features are not collected.
- **Correction:** Report the observed inventory, not proposed counts; use a verified schedule-only dataset first.

### F19 — CRITICAL — 4

- **Original claim:** The local calendar is fully verified point-in-time.
- **Evidence:** CSV FOMC dates 2026-11-05 and 2026-12-16; official Fed 2026 meetings end 2026-10-28 and 2026-12-09; BLS archive fetch blocked by HTTP403
- **Assessment:** Two FOMC dates conflict with the official calendar. Four CSV rows are future schedules at audit time, not observed releases. CPI/NFP timestamps convert to 08:30 New York, but this does not verify release dates or historical schedule availability.
- **Correction:** Repair dates against dated primary archives; preserve schedule vintages and distinguish scheduled events from observed releases.

### F20 — HIGH — 4

- **Original claim:** An event clock or post-release surprise column guarantees zero leakage.
- **Evidence:** DATASET_COLLECTION_SPECIFICATION.md:116-123; MASTER_METHODOLOGY_REVISION_DOSSIER.md:114-121
- **Assessment:** Need historical schedule knowledge, first-release Actual/Forecast vintages, publication/ingestion latency, and past-only surprise scaling. Countdown units also differ between the dossier and dataset spec.
- **Correction:** Join on available_at <= decision_at and fix minutes-vs-hours, past-vs-next-event and revised-value rules.

### F21 — HIGH — 4

- **Original claim:** A spike in event-window variance proves causality.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:123-125
- **Assessment:** Variance association around an event does not establish a causal effect or eliminate simultaneous-event confounding and endogenous order flow.
- **Correction:** Use predictive language unless an explicit identification design and assumptions are justified.

### F22 — CRITICAL — 5

- **Original claim:** Clean/sweep/collapse labels are mutually exclusive and complete.
- **Evidence:** DATASET_COLLECTION_SPECIFICATION.md:129-139; MASTER_METHODOLOGY_REVISION_DOSSIER.md:134-155
- **Assessment:** A path through -1.1 ATR then +2 ATR qualifies for a sweep but also breaches the collapse/market stop. A +2 ATR winner with 0.6 ATR retracement falls between clean and sweep definitions. Shorts and precedence need explicit treatment.
- **Correction:** Define exclusive first-hit outcomes first; keep path descriptors separate from each execution policy’s actual P&L.

### F23 — CRITICAL — 5 / Execution

- **Original claim:** 15m OHLC proves TP-before-SL and limit-fill ordering.
- **Evidence:** DATASET_COLLECTION_SPECIFICATION.md:127-139; proposed hybrid execution policy
- **Assessment:** Both barriers can be touched within one candle without known event order. Neither a touch nor one-tick penetration is a queue-fill guarantee.
- **Correction:** Use finer-resolution data, retain an ambiguity flag and predefine conservative resolution; later compare limit fills to real executions.

### F24 — CRITICAL — 6

- **Original claim:** The proposed prototypical MLP is simply the implemented X-Trend extension.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:171-183; Wood v2 physical p.2; Snell arXiv:1703.05175v2 abstract
- **Assessment:** The proposal is a three-linear-layer prototype classifier, whereas X-Trend uses cross-attention over regime sequences. They are distinct model families.
- **Correction:** Choose one main model explicitly; treat X-Trend and prototypical networks as separate baselines/candidates.

### F25 — CRITICAL — 6

- **Original claim:** Any recent examples can populate the support set immediately.
- **Evidence:** proposed H=8 labels and class support centroids; MASTER_METHODOLOGY_REVISION_DOSSIER.md:178-183
- **Assessment:** A support example’s future-dependent label must have finished before the query decision. Support selection, clustering/change-point detection and scaling can leak future information.
- **Correction:** Enforce support.label_end < query.decision_at and fit all selection/normalization on past data only.

### F26 — HIGH — 6

- **Original claim:** A fixed three-class embedding automatically establishes a few-shot adaptation contribution.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:159-186
- **Assessment:** Episodes, task/regime identity, held-out regimes, number of shots and support update budget are unspecified. It may reduce to supervised metric learning plus nearest prototypes.
- **Correction:** Define the adaptation task and compare equal-information rolling, retrieval and supervised baselines.

### F27 — HIGH — 6

- **Original claim:** Distance thresholding is a conformal gate with guaranteed abstention reliability.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:185-186
- **Assessment:** No nonconformity score, calibration split, alpha or applicable coverage assumptions are specified. The threshold rule is a heuristic rejection gate.
- **Correction:** Rename it or supply a separately justified, time-aware conformal calibration protocol.

### F28 — HIGH — 7

- **Original claim:** A class-weighted cross-entropy plus unspecified drawdown penalty enforces prop-firm safety.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:196-200
- **Assessment:** A sequential equity/position process and differentiable objective are not defined. Mini-batch classification cannot alone guarantee drawdown, daily loss or broker compliance.
- **Correction:** Start with a simple prediction loss and a deterministic risk-control layer; verify actual firm rules separately.

### F29 — CRITICAL — 8

- **Original claim:** N=6,k=2 CPCV gives 15 full backtest paths and guarantees live no-lookahead.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:206-210; tool calculation: 15 splits, 5 recombined paths
- **Assessment:** 15 is the split count, not the number of full recombined paths. Retrospective CPCV can train on dates later than a test block; it is not a substitute for deployment-faithful forward testing.
- **Correction:** Use nested chronological walk-forward as primary, exact label-interval purging, and CPCV only as a clearly labeled supplementary retrospective analysis.

### F30 — CRITICAL — 8 / Execution

- **Original claim:** 4bps taker/2bps maker and one fixed tick adequately model all costs and split-order fills.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:212-216; hybrid policy in project notes
- **Assessment:** Fees are charged on applicable entries and exits; spreads, funding, latency, gaps, queue risk and partial/unfilled orders also matter. Fixed USD0.50 tick and universal fee-tier claims are not verified.
- **Correction:** Use actual contract/fee schedules or labeled conservative scenarios; model both legs and stress costs. Keep market-only execution for the initial baseline.

### F31 — HIGH — 8

- **Original claim:** A positive shuffled-label Sharpe proves leakage, and a DSR p<.01 gate by itself validates the edge.
- **Evidence:** MASTER_METHODOLOGY_REVISION_DOSSIER.md:218-226; DSR DOI metadata 10.3905/jpm.2014.40.5.094
- **Assessment:** Positive performance can arise from drift/chance under a null. Naive permutations destroy temporal dependence. DSR needs correct multiple-trial, dependence, moment and sample treatment, not just a named threshold.
- **Correction:** Use a valid dependence-preserving null distribution plus direct timing/causality unit tests; document every selection trial and confidence interval.

### F32 — CRITICAL — Citation integrity

- **Original claim:** SSRN 7356724 is peer-reviewed evidence of >40% Sharpe improvement from OI meta-labeling.
- **Evidence:** BINANCE_DATA_AND_BASE_PAPER.md:60-63; Crossref posted-content record and JATS abstract
- **Assessment:** The retrieved abstract reports weak discrimination, contract-dependent signs, and no paired 95% interval excluding zero under either seed. It is a working-paper record, not established peer-reviewed proof of universal improvement.
- **Correction:** Correct the quoted finding, type and uncertainty; preserve the negative evidence.

### F33 — HIGH — Citation integrity

- **Original claim:** A resolving DOI verifies all attached metrics or a first-ever claim.
- **Evidence:** 86 unique local DOI tokens inventoried; bounded 50-record lookup; SSRN 10.2139/ssrn.3607074 unresolved in this pass
- **Assessment:** Metadata resolution is separate from identity matching, publication status and claim support. Residual citations and claimed metrics need source-level verification.
- **Correction:** Use the saved ledger; retain unresolved metadata as [CITATION NEEDED] and never promote discovery manifests to evidence automatically.

### F34 — MEDIUM — Scope

- **Original claim:** ETH/SOL transfer is mandatory and already collected / exactly matches the Oxford protocol.
- **Evidence:** DATASET_COLLECTION_SPECIFICATION.md:143-150; 27-file inventory; no ETH/SOL market-data artifacts
- **Assessment:** Cross-asset transfer can improve external validity, but is optional and uncollected. Overlapping BTC training dates with test-asset dates are not automatically temporal OOS.
- **Correction:** Respect the BTC-first scope; add cross-asset tests only after approval, with frozen dates and adaptation budgets.

### F35 — HIGH — Metrics

- **Original claim:** PF>=1.6, win rate>=45%, MDD<=4%, abstention>=50% demonstrate a Q1/institutional edge.
- **Evidence:** PROJECT_GOAL.md; RESEARCH_PROPOSAL.md; computed gross 45%-at-2R expectancy=0.35R before costs
- **Assessment:** These are proposed engineering targets, not observed results or publication criteria. Aggregate MDD differs from daily loss, and abstention over all signals differs from filtering false signals.
- **Correction:** Report traded sample sizes, coverage, uncertainty, risk/exposure matched baselines and net returns; keep research conclusions independent of profit targets.

## Appendix B — Every inspected source artifact

1. `30_DAY_MASTER_PLAN.md` — 22,985 bytes; 255 extracted text lines; mode `full_text_local`. SHA-256: `ac9859150b525ab4ac5a0fc11ebb067f95fbc490f0b7ee20bf1f833d4b361c2f`.
2. `BASE_PAPER_MASTER_CLASSNOTES.md` — 16,916 bytes; 230 extracted text lines; mode `full_text_local`. SHA-256: `5b73809f64869bbabc08fa8c577a8e7e315e8390355e8f4e87e2f36a48a26b8b`.
3. `BINANCE_DATA_AND_BASE_PAPER.md` — 6,747 bytes; 101 extracted text lines; mode `full_text_local`. SHA-256: `15a88fe1d404cbd73e709622a90c9cb3b405e75c0539567e8a113158cea6837b`.
4. `DATASET_COLLECTION_SPECIFICATION.md` — 9,390 bytes; 150 extracted text lines; mode `full_text_local`. SHA-256: `7c2be7bb3ee6103879ec38ce27139274fc09731d2c2099e72a8ab8af078f3778`.
5. `DAY_01_BASE_PAPER_STUDY.md` — 5,375 bytes; 73 extracted text lines; mode `full_text_local`. SHA-256: `2f838ecddbad617972cdac36c0f29bec52f4c6ecbdcb05f359cdaffea3da614e`.
6. `FEW_SHOT_LEARNING_100_ASPECTS.md` — 2,262 bytes; 17 extracted text lines; mode `full_text_local`. SHA-256: `b5173fb0b0929c34f279a2c4ab0d8b8e97043e85354f308b0984e56517adb4c3`.
7. `LEARNING_JOURNAL.md` — 3,440 bytes; 54 extracted text lines; mode `full_text_local`. SHA-256: `7b30bc7595ce74fcb7dc75d8d6b21e5a91d8a193e71e4f7ed107e30ca1de355d`.
8. `MASTER_METHODOLOGY_REVISION_DOSSIER.md` — 16,283 bytes; 239 extracted text lines; mode `full_text_local`. SHA-256: `e28f909fe0a2a8df30292a0d1de4f79e06235f210b7465ead37cb64f684e12bc`.
9. `NEWS_DATASET_TAXONOMY.md` — 6,606 bytes; 93 extracted text lines; mode `full_text_local`. SHA-256: `80c8d79f52012c87778f4425c21333d42f49a953016126917aa5ba7c6fe3435b`.
10. `PROJECT_GOAL.md` — 2,752 bytes; 35 extracted text lines; mode `full_text_local`. SHA-256: `abfca727c52dfe31d110e28aff096e1dc266d7e5a474d6dd63fe7b6bdebc71a8`.
11. `Q1_PEER_REVIEW_REJECTION_AUDIT.md` — 10,954 bytes; 105 extracted text lines; mode `full_text_local`. SHA-256: `6fd90160f8d0b713287eb3d8e41d944e8550e7d2679bf23ac3d316cf20e9304a`.
12. `RESEARCH_PROPOSAL.md` — 18,427 bytes; 219 extracted text lines; mode `full_text_local`. SHA-256: `acd5121bc946a2e29644d722874fe45813557cc7e2f0b9cf4bc5201cbdaec1e2`.
13. `RESEARCH_QUESTIONS_AND_ANSWERS.md` — 136,965 bytes; 1952 extracted text lines; mode `full_text_local`. SHA-256: `f44a911df33fd1355de1cb010e48ecc65c7a21b72b776d045c26092370f3dd8b`.
14. `SLIDES_DECK.md` — 5,350 bytes; 103 extracted text lines; mode `full_text_local`. SHA-256: `3d4f466ff8fc514d25c7c00e36318be102c1827e2610da3bbf4524149e758fb0`.
15. `all_news_citations.json` — 3,614 bytes; 148 extracted text lines; mode `full_text_local`. SHA-256: `28b80bf3899972fb4d735180eec5ae8655e55d2714b31e6b68f0e87acd11567e`.
16. `calendar_us_2021_2026.csv` — 27,116 bytes; 193 extracted text lines; mode `full_text_local`. SHA-256: `dc05c74ce1f5ea228fb282a925e6a7b3b9314f77940e16dc197b89d2fe3b1423`.
17. `ce_candidate_citations.json` — 2,959 bytes; 119 extracted text lines; mode `full_text_local`. SHA-256: `a579286dfed6aecdf7320d661b6b378da807fe61dc17fba336cb4af0b25525b5`.
18. `chandelier_exit.pine` — 3,396 bytes; 57 extracted text lines; mode `full_text_local`. SHA-256: `6f0e3155ab53c5007505bb9caa9e369d8b27d088b23a85a1e0524e71256b3d4a`.
19. `macro_orderflow_papers.json` — 3,795 bytes; 156 extracted text lines; mode `full_text_local`. SHA-256: `4106bad1d2403e15c9fb509eab929a0a46a928c8e6a82c7ac5e6e252c522b41c`.
20. `news_few_shot_papers.json` — 3,566 bytes; 140 extracted text lines; mode `full_text_local`. SHA-256: `b562273fec7b188e80f782cbff1e56ce581100e9a4df8b9b7d8f12b711d98964`.
21. `news_impact_ranking_papers.json` — 3,277 bytes; 126 extracted text lines; mode `full_text_local`. SHA-256: `f3253bdcae8bb96db71292852ada0d048c30133cb4a7b0a2a4f33251056e5fe8`.
22. `numerical_news_ml_papers.json` — 4,614 bytes; 180 extracted text lines; mode `full_text_local`. SHA-256: `7225d9f85c3728850679a868aa568651e7e9243a7831b41165ca7ebce86747ad`.
23. `orderflow_news_papers.json` — 2,060 bytes; 89 extracted text lines; mode `full_text_local`. SHA-256: `341acea7093c8818d68f9af081a8dc480e5c282a4ae8a10af3788584816202cb`.
24. `spoofing_manipulation_papers.json` — 1,834 bytes; 79 extracted text lines; mode `full_text_local`. SHA-256: `90e5e6a13870031ec9f152256d7f7d31b91d9ca54d7e988bb1299d7b2f55a204`.
25. `vwap_ce_papers.json` — 3,372 bytes; 137 extracted text lines; mode `full_text_local`. SHA-256: `2b1126cb155e447abebe8b6f6998874ff1162a3da700616e3c8258eb5d19c44b`.
26. `wood_et_al_2024_x_trend_base_paper.pdf` — 2,044,662 bytes; 1475 extracted text lines; mode `full_pdf_text_layer`. SHA-256: `4c9ca4908bd6a5ab46c8c91fbb50e953a01801e2d1f6822f388d5441fac4afc0`.
27. `x_trend_base_paper_slides.html` — 18,323 bytes; 426 extracted text lines; mode `full_text_local`. SHA-256: `64a74b8d97eddbd2bfd817bf27ee2a60d09d1b868f56bef83b7b8f5cb32f99fa`.

All scientific acceptance statuses remain proposed/unverified until actual execution evidence exists.
