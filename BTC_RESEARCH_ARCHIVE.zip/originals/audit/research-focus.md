# Proposed Research Focus: Few-Shot Adaptation of Order-Flow Models Conditioned on News

## Status and scope

This is a **proposed research framing**, not a verified novelty claim, an approved experiment, a proven trading edge or a Q1 acceptance prediction. It preserves the owner's central idea: apply few-shot learning to order flow and news to investigate shortcomings of trading-bot/ML predictions. The Chandelier Exit is a candidate-event generator, not the proposed scientific novelty; VWAP is optional rather than necessary.

The earlier audit remains applicable: indicator parity, calendar correctness, label exclusivity, point-in-time inputs and execution assumptions need repair before experiments. No source project file outside ResearchStudio is modified by this note.

## 1. Result — a specific issue worth testing

**[Hypothesis]** Order-flow models trained on past market conditions may generalize poorly to later regimes, and the relationship between executed aggressor flow and subsequent price paths may differ across scheduled-news contexts. A few-shot adaptation mechanism could use a limited number of legally available, completed examples to adjust predictions in a later regime.

This is a testable proposed failure mode, not an established fact that all order-flow models fail or that few-shot learning must outperform ordinary retraining.

**Research question:**

> Under a fixed, past-only adaptation budget, does news-conditioned few-shot adaptation improve an executed-order-flow model's predictions in later BTC intraday regimes compared with ordinary training/retraining using the same inputs?

**Potential mechanism to investigate:** select or weight support examples using both executed-flow patterns and the news context known at the decision time. Compare this with generic support selection and ordinary feature concatenation. Do not describe this proposed mechanism as novel until the closest-work search is complete.

## 2. Evidence and boundaries

- Wood, Kessler, Roberts and Zohren (2024), *Few-Shot Learning Patterns in Financial Time Series for Trend-Following Strategies*. DOI: https://doi.org/10.3905/jfds.2024.1.157 ; acquired version https://arxiv.org/abs/2310.10500v2 . Access: `full_text` local preprint, canonical journal metadata separately checked. It motivates few-shot regime/context adaptation; it does not validate our proposed order-flow/news repair mechanism. Author-reported trading performance was not reproduced.
- Zhang et al. (2025), *CAMEF: Causal-Augmented Multi-Modality Event-Driven Financial Forecasting by Integrating Time Series Patterns and Salient Macroeconomic Announcements*. DOI: https://doi.org/10.1145/3711896.3736872 ; https://arxiv.org/html/2502.04592v3 . Access: `full_text` preprint plus verified proceedings metadata. It is related macroeconomic multimodal forecasting, not proof that our particular adaptation method is solved or novel.
- The prior audit records related news-based few-shot work and 15m OI meta-labeling, plus important null/mixed evidence. A dedicated closest-work review of few-shot/domain adaptation with order flow remains necessary.

For the current free BTC kline dataset, **order flow means executed buyer/seller aggressor volume and derived rolling measures**. It does not mean a complete order-level history, institutional identities or validated spoofing detection. Scheduled-news clocks are not pre-release surprise values or breaking-news text. Any broader claim requires matching data.

## 3. Decision — isolate the proposed contribution

A minimum controlled comparison uses four conditions:

1. Ordinary ML with executed order flow.
2. Ordinary ML with executed order flow plus legally available news context.
3. Few-shot adaptation with executed order flow.
4. Few-shot adaptation with executed order flow plus the same news context.

Use the same signal candidates, outcome definitions, train/validation/test dates, information availability, tuning resources and execution assumptions. Add a support-selection ablation comparing news-conditioned selection with a generic selection rule. Compare a regularized linear model and a tree model; the proposed few-shot model family must be selected explicitly rather than conflating X-Trend with a prototypical MLP.

Specify what a task/new regime is, how it is identified online, how many matured labels are permitted, and when support updates occur. Regime/domain adaptation with fixed outcome classes is not automatically the same as few-shot recognition of entirely new classes.

### Outcomes and metrics — proposed, not preregistered

- Define exclusive TP-first/SL-first/timeout outcomes for one executable policy before adding descriptive trajectory archetypes.
- Select one predictive primary metric in the protocol, such as probability log loss over the same candidate events. Report calibration and uncertainty.
- Evaluate fee/funding/spread-adjusted economic results separately under a common risk budget; prediction improvements are not automatically profits.
- Freeze temporal holdouts and the adaptation/tuning budget. All learned transforms and support-selection rules must be fit using legal past information.

## 4. Confidence, uncertainty and falsifiers

**[Agent Inference]** This focused question is a plausible applied-research direction. It is stronger than an ingredient-list contribution only if it establishes a previously inadequately measured adaptation problem and a defensible finding or mechanism.

**[Hypothesis]** Joint news/flow conditioning helps few-shot adaptation beyond the same information in ordinary ML. Profitability, superiority, novelty and publication acceptance are unknown.

Falsifiers include:
- Flow-plus-news ordinary ML matches or beats the few-shot method under the same legal inputs and resources.
- News conditioning adds no repeatable benefit over flow-only few-shot adaptation.
- Apparent improvement vanishes under chronological testing, matured-label support rules or realistic costs.
- The chosen baseline does not suffer the proposed adaptation problem.

A null result must be preserved. It may provide useful knowledge, but a negative result is not automatically a strong publication without a consequential question and rigorous design.

## 5. Next step and approval gate

First document the proposed baseline failure and define the adaptation task and falsifier. Then repair the minimum dataset/label contract before a bounded, owner-approved pilot. No training, packages, large downloads or external contacts are authorized by this note.

Protocol approval: **not yet granted**. Model family, shot budget, holdout dates, primary metric, compute budget and experiment execution remain to be agreed.

## 6. Learning note and exercise

The four-condition comparison separates the value of additional news information from the value of few-shot adaptation. Without ordinary ML plus the same news inputs, an improvement cannot fairly be credited to few-shot learning.

**Exercise:** The joint few-shot model beats an order-flow-only baseline but ties ordinary ML with order flow plus news. What did the comparison establish, and which few-shot superiority claim must be withdrawn?

Concepts introduced: hypothesis versus promised outcome; information-matched baselines; few-shot domain/regime adaptation; label maturity; predictive versus economic value. Owner mastery has not been assessed.

## 7. Artifact links

- This proposed focus: `~/ResearchStudio/audits/btc-20261109T131024Z/research-focus.md`
- Full earlier audit: `~/ResearchStudio/audits/btc-20261109T131024Z/REVIEW.md`
- Source identities, access modes and raw evidence: `citation-ledger.json` and `source-evidence.json` in the same audit folder.
