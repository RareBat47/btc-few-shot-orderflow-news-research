# Research Apprenticeship Learning Journal

**Apprentice / Principal Investigator:** Arifin Nabid  
**Mentor & Research System:** Research Apprenticeship Mentor & Systems Researcher  
**Active Project:** Few-Shot Trajectory Archetype Prediction in Intraday Bitcoin  
**Base Paper:** Wood, Kessler, Roberts, & Zohren (Oxford-Man Institute, *JFDS* 2024 / arXiv:2310.10500)  
**Apprenticeship Mode:** `/mode learn` (Socratic, First-Principles Pedagogical Framework)  

---

## Pedagogical Contract & Learning Framework

To ensure complete, deep mastery of every mathematical equation, econometric mechanism, and coding module without shortcuts, every lesson follows the **4-Step Mastery Cycle**:

1. **Intuition & Market Mechanics (The "Why"):** Plain-English conceptual breakdown using concrete trading analogies (order books, liquidity pools, market-maker behaviors).
2. **Mathematical Formalization (The "How"):** Exact mathematical formulation (loss functions, probability distributions, tensor algebra, attention mechanisms).
3. **Socratic Challenge / Code Verification (The "Test"):** A targeted problem or code exercise that you must answer or solve to prove understanding before we proceed.
4. **Research Log Sign-off:** Documenting verified concepts, cleared misconceptions, and tracking progress against our 30-Day Master Plan.

---

## Core Subject Curriculum

### Module 1: The Base Paper (Wood et al., 2024 - Oxford-Man Institute)
- **Topic 1.1:** Time-Series Non-Stationarity & Why Standard Deep Learning Fails in Crashes.
- **Topic 1.2:** Bayesian Online Change-Point Detection (BOCPD) & Market Regime Segmentation.
- **Topic 1.3:** Cross-Attention Tensor Algebra: Query (Target Regime) vs. Key/Value (Historical Regimes).
- **Topic 1.4:** Differentiable Sharpe Ratio Optimization & Vanishing Gradient Pitfalls.
- **Topic 1.5:** Threat-to-Validity Audit: Why X-Trend's daily macroscopic model fails on intraday crypto.

### Module 2: Market Microstructure & Order Flow Mechanics
- **Topic 2.1:** Limit Order Books (LOB) vs. Market Orders: Maker-Taker Dynamics.
- **Topic 2.2:** Order Flow Delta, CVD (Cumulative Volume Delta), and Aggressive Volume Imbalance.
- **Topic 2.3:** Absorption vs. Exhaustion: Spotting institutional icebergs and liquidity sweeps.
- **Topic 2.4:** Point-in-Time Data Discipline: Microsecond timestamp alignment and preventing lookahead leakage.

### Module 3: Few-Shot Metric Learning & Prototypical Networks
- **Topic 3.1:** Metric-Based Meta-Learning (Snell et al. / Wood et al.) vs. Gradient-Based MAML.
- **Topic 3.2:** Latent Embedding Spaces: Projecting high-dimensional noisy features into geometric clusters.
- **Topic 3.3:** Class Prototypes & Euclidean Distance Boundaries: Formulating the 3 Trajectory Archetypes.
- **Topic 3.4:** The Conformal Trade-Abstention Mechanism: Knowing when the model does not know.

### Module 4: Econometric Rigor & Quantitative Falsification
- **Topic 4.1:** The Triple-Barrier Method (López de Prado) & Horizon Expirations.
- **Topic 4.2:** Backtest Overfitting, Multiple Testing Bias, and the Deflated Sharpe Ratio (Bailey et al.).
- **Topic 4.3:** Combinatorial Purged Cross-Validation (CPCV) vs. Walk-Forward Testing.
- **Topic 4.4:** Target Shuffling Noise Tests: Proving genuine statistical edge over random luck.

---

## Apprenticeship Progress Log

- **Status:** Initialized.
- **Current Milestone:** Ready for Day 1 Kick-off (Module 1, Topic 1.1).
