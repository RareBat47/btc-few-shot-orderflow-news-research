---
marp: true
theme: gaia
_class: lead
paginate: true
backgroundColor: #0b0f19
color: #f8fafc
---

# **X-Trend: Few-Shot Learning in Financial Time-Series**
### Deconstructing the Oxford Base Paper for Trend-Following Strategies
**Authors:** Kieran Wood, Samuel Kessler, Stephen J. Roberts, Stefan Zohren  
**Institution:** Oxford-Man Institute of Quantitative Finance, University of Oxford  
**Publication:** *The Journal of Financial Data Science* (Spring 2024)

---

## 1. The Fatal Flaw of Modern Trading AI
- **The I.I.D. Lie:** Standard models (LSTMs, Transformers) assume markets never change ($P_{\text{train}} \approx P_{\text{test}}$).
- **The Bull Trap:** During calm markets, models learn: *"Every dip is a buying opportunity."*
- **The Crash Reality:** In March 2020 (COVID-19), the Dow plunged 6,400 points in 4 days.
- **The Failure:** The AI kept buying the crash all the way down, suffering maximum account liquidations.
- **The Retraining Trap:** Deep models require hundreds of new samples to update weights via gradient descent ($>180$ days). By then, capital is gone.

---

## 2. The Solution: Memory Bank vs. Static Weights
- **How Experienced Humans Trade:** A veteran trader does not re-learn trading during a panic. They remember 2008 and adapt immediately.
- **The Oxford X-Trend Innovation:**
  - Instead of static weights, the AI carries a **Context Memory Bank** of historical market crashes.
  - When today's market gets turbulent, it uses a **Transformer Cross-Attention layer** to search its memory:
    > *"Today's market looks 80% similar to October 2008."*
  - It immediately borrows the winning position strategy from that past regime!

---

## 3. The Core Architecture: Cross-Attention
$$\text{Attention}(Q, K, V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$$

- **$Q$ (Query):** What today's market looks like right now (last 21 bars).
- **$K$ (Keys):** Signatures of historical market regimes in the memory bank.
- **$QK^T$:** Computes the mathematical similarity between today and historical crises.
- **$V$ (Values):** The winning position vectors that succeeded during those past regimes.
- **Output:** Squeezed via $\tanh$ into a continuous trading position $z_t \in [-1.0, +1.0]$.

---

## 4. Step 1: Bayesian Change-Point Detection (BOCPD)
- **Why Calendar Months Fail:** Slicing data by "January 2020" or "March 2020" blends crashes and calm trends into meaningless noise.
- **Statistical Slicing:** BOCPD mathematically tracks changes in return mean $\mu$ and volatility $\sigma$.
- **Result:** Slices 33 years of futures data into clean, discrete regime chapters:
  - *Calm Trend Regimes*
  - *Violent Liquidation Regimes*
  - *Sideways Choppy Regimes*

---

## 5. The Loss Function: Differentiable Sharpe Ratio
- **Why Not Mean Squared Error (MSE)?** Predicting price numbers does not equal trading profit.
- **Direct Sharpe Optimization:**
  $$\mathcal{L} = -\text{Sharpe}(R_{1:T}) = -\frac{\mathbb{E}[R_t]}{\sqrt{\text{Var}(R_t)}}$$
  $$R_t = z_t \cdot r_{t+1} - c \cdot |z_t - z_{t-1}|$$
- **The Power of Backprop:** Forces the neural network to:
  1. Maximize trend returns.
  2. Minimize equity volatility swings.
  3. Directly penalize over-trading fees ($c \cdot |z_t - z_{t-1}|$).

---

## 6. The 33-Year Institutional Experiment
- **Data Universe:** 50 liquid continuous futures contracts across Commodities (Gold, Oil), Equities (S&P 500, DAX), Bonds (US 10Y), and Currencies (EUR, JPY).
- **Time Horizon:** 1990 to 2023 (33 continuous years covering Dot-Com, 2008 Lehman, and 2020 COVID).
- **Baselines Beaten:**
  1. Time-Series Momentum (TSMOM - the industry CTA benchmark).
  2. Deep Momentum Networks (LSTM-based trading system).
  3. Static Transformers without memory.

---

## 7. Key Empirical Results
- **+18.9% Sharpe Ratio Gain:** Outperformed state-of-the-art neural forecasters during the turbulent 2018–2023 period.
- **10-Fold Higher Sharpe:** Demolished the traditional rule-based CTA momentum benchmark.
- **2x Faster Crash Recovery:** Recovered from the March 2020 COVID drawdown in half the time of other models.
- **Zero-Shot Asset Transfer (5x Boost):** When deployed on brand-new financial instruments it had never seen before, X-Trend achieved a 5-fold Sharpe increase by recognizing recurring patterns.

---

## 8. What Oxford Missed (Our Q1 Research Gap)
1. **Gap 1: Blind to Order Flow Microstructure:**
   - Oxford only used daily close prices. They had zero access to buyer vs. seller volume.
   - **Our Contribution:** Inject Binance 15m Taker Order Flow Delta & CVD.
2. **Gap 2: Blind to Macro News Clocks:**
   - Oxford treated all days equally, ignoring scheduled volatility bombs (FOMC/CPI).
   - **Our Contribution:** Point-in-time Macro Countdown Clock (`minutes_to_news`).
3. **Gap 3: Unstructured Execution:**
   - Oxford output continuous numbers with no stop-losses or profit targets.
   - **Our Contribution:** Chandelier Exit 2:1 R:R Trajectory Archetype Engine.

---

## 9. Executive Conclusion
- **Oxford Base Paper Proved:** Memory-augmented Few-Shot Learning stops algorithmic trading bots from blowing up during market regime shifts.
- **Our Q1 Research Frontier:** We take Oxford's macro-crisis memory architecture, scale it down to 15-minute Bitcoin trading, and feed it centralized order flow and macroeconomic countdown clocks.
