# Master Methodology Revision Dossier: Autonomous Intraday Few-Shot Trading Engine

**Document Identifier:** MMRD-BTC-15M-2026-V1  
**Project:** Few-Shot Trajectory Archetype Prediction in Intraday Bitcoin  
**Repository:** `/home/rarebat/PORTFOLIO/Signal/BTC/`  
**Target Manuscript:** *The Journal of Financial Data Science* (JFDS) / *Quantitative Finance*  
**Principal Investigator:** Arifin Nabid  
**Research Mentor:** Research Apprenticeship Mentor & Systems Researcher  

---

## Master Revision Architecture: The 8 Sequential Pillars

```
┌────────────────────────────────────────────────────────────────────────┐
│ Pillar 1: Research Epistemology, Hypotheses & Non-Stationarity         │
├────────────────────────────────────────────────────────────────────────┤
│ Pillar 2: Primary Heuristic Engine (Chandelier Exit & Session VWAP)    │
├────────────────────────────────────────────────────────────────────────┤
│ Pillar 3: Microstructure & Centralized Order Flow Data Engineering     │
├────────────────────────────────────────────────────────────────────────┤
│ Pillar 4: Point-in-Time Macroeconomic Event Architecture & Surprise Z  │
├────────────────────────────────────────────────────────────────────────┤
│ Pillar 5: Post-Signal Trajectory Archetypes & Triple-Barrier Labeling  │
├────────────────────────────────────────────────────────────────────────┤
│ Pillar 6: Few-Shot Metric Embedding Network (The Oxford Extension)     │
├────────────────────────────────────────────────────────────────────────┤
│ Pillar 7: Asymmetric Loss Formulations & Prop-Firm Barrier Objectives  │
├────────────────────────────────────────────────────────────────────────┤
│ Pillar 8: Combinatorial Purged Cross-Validation & Falsification Rigor   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## Pillar 1: Research Epistemology, Hypotheses & Non-Stationarity

### 1.1 The Theoretical Gap & Research Question
- **Primary Research Question:** Can a few-shot metric learning network—conditioned on centralized taker order flow and macroeconomic announcement proximity—distinguish profitable post-breakout trajectory archetypes from false whipsaws in intraday cryptocurrency futures?
- **Formal Hypotheses:**
  - **Null Hypothesis ($H_0$):** Conditioning an ATR-based trend heuristic on few-shot order-flow prototypes and macroeconomic countdown clocks yields an out-of-sample Sharpe ratio and profit factor statistically indistinguishable from the un-filtered indicator baseline ($\Delta \text{Sharpe} \le 0, p \ge 0.05$).
  - **Alternative Hypothesis ($H_1$):** Few-shot trajectory conditioning produces a statistically significant out-of-sample performance improvement ($\Delta \text{Sharpe} > 0, p < 0.01$) after deducting exchange fees and slippage, reducing peak-to-trough drawdown by $\ge 40\%$.

### 1.2 Mathematical Failure of Empirical Risk Minimization (ERM)
- Standard deep learning minimizes empirical risk over past historical training sets:
  $$\theta^* = \arg\min_\theta \frac{1}{N} \sum_{i=1}^N \mathcal{L}(f_\theta(X_i), y_i)$$
- In financial econometrics (*Chris Brooks, Introductory Econometrics for Finance, p. 348*), asset prices are non-stationary unit root processes ($I(1)$) with time-varying conditional volatility and structural breaks:
  $$P_t(X, y) \neq P_{t + \Delta t}(X, y)$$
- **The Failure Mode:** When an abrupt regime shock occurs (e.g., COVID-19 March 2020 crash, FTX collapse, emergency rate hikes), static weights $\theta^*$ optimized for pre-crash drift continue taking losing trades. X-Trend (Wood et al., 2024) proves that few-shot context conditioning adapts in $<5$ bars without slow gradient retraining.

---

## Pillar 2: Primary Heuristic Engine (Chandelier Exit & Session VWAP)

### 2.1 The Chandelier Exit Directional Trigger
- **Formal Academic Definition:** Alexander Elder (2002); Charles LeBeau & David Lucas (1992).
- **Core Formula:**
  $$\text{ATR}_{14}(t) = \frac{1}{14} \sum_{i=0}^{13} \text{TR}_{t-i}$$
  $$\text{TR}_t = \max(\text{High}_t - \text{Low}_t, |\text{High}_t - \text{Close}_{t-1}|, |\text{Low}_t - \text{Close}_{t-1}|)$$
  $$\text{Long Stop}_t = \max_{i \in [0, 21]} (\text{Close}_{t-i}) - 3.0 \times \text{ATR}_{14}(t)$$
  $$\text{Short Stop}_t = \min_{i \in [0, 21]} (\text{Close}_{t-i}) + 3.0 \times \text{ATR}_{14}(t)$$
- **Directional State Variable:**
  $$\text{dir}_t = \begin{cases} +1 & \text{if } \text{Close}_t > \text{Short Stop}_{t-1} \\ -1 & \text{if } \text{Close}_t < \text{Long Stop}_{t-1} \\ \text{dir}_{t-1} & \text{otherwise} \end{cases}$$
- **Candidate Signal Event:** Triggered at bar $t$ if and only if $\text{dir}_t \neq \text{dir}_{t-1}$.

### 2.2 Session Volume-Weighted Average Price (VWAP) Value Anchor
- Evaluates whether the candidate breakout is trading at an institutional premium or discount:
  $$\text{VWAP}_t = \frac{\sum_{i \in \text{Session}} P_{i, \text{typical}} \times V_i}{\sum_{i \in \text{Session}} V_i}, \quad P_{\text{typical}} = \frac{H + L + C}{3}$$
- **Normalized VWAP Distance Feature:**
  $$\Delta \text{VWAP}_t = \frac{\text{Close}_t - \text{VWAP}_t}{\text{ATR}_{14}(t)}$$

---

## Pillar 3: Microstructure & Centralized Order Flow Data Engineering

### 3.1 Raw Data Ingestion from Binance Vision
- Source: Monthly archives of `BTCUSDT` Perpetual Futures klines (`data.binance.vision`).
- Pre-aggregated columns utilized:
  - `open_time`, `open`, `high`, `low`, `close`, `volume`, `close_time`, `count`
  - `taker_buy_volume`: Aggressive market orders executed by buyers crossing the spread.
  - `taker_buy_quote_volume`: Total aggressive dollar volume.

### 3.2 Order Flow Metrics Mathematical Formulations
- **Aggressive Buyer vs. Seller Volume:**
  $$V_{\text{buy}, t} = \text{taker\_buy\_volume}_t$$
  $$V_{\text{sell}, t} = \text{volume}_t - \text{taker\_buy\_volume}_t$$
- **Bar Delta:**
  $$\text{Delta}_t = V_{\text{buy}, t} - V_{\text{sell}, t} = 2 \times V_{\text{buy}, t} - \text{volume}_t$$
- **Cumulative Volume Delta (CVD) Momentum:**
  $$\text{CVD}_{4, t} = \sum_{i=0}^3 \text{Delta}_{t-i}$$
- **Normalized Order Flow Delta:**
  $$\text{Delta}_{\text{norm}, t} = \frac{\text{Delta}_t}{\overline{V}_{96}}$$

### 3.3 Microstructure Spoofing & Manipulation Defense
- Based on Cartea, Jaimungal, & Wang (2020) and Hasbrouck & Saar (2013):
- **Why We Are Immune to Spoofing:** Resting limit order walls (Level 2 DOM) can be canceled for free. Executed Taker Delta requires paying real exchange fees and crossing the spread. Our model trains strictly on executed taker volume.
- **Absorption Divergence Flag:**
  $$\text{Divergence}_t = \begin{cases} 1 & \text{if } \Delta \text{Price}_t > 0 \text{ and } \text{Delta}_t < 0 \\ 0 & \text{otherwise} \end{cases}$$
  Flags when smart money is passively absorbing retail breakout buyers.

---

## Pillar 4: Point-in-Time Macroeconomic Event Architecture & Surprise Z

### 4.1 The Expanded 1,030+ Event Universe
- Spans 5 years (2021 to 2026) across 5 core categories:
  1. *Monetary Policy & Fed:* FOMC Statements, Minutes, Powell Speeches (200 events).
  2. *Inflation Metrics:* CPI Headline/Core, Core PCE, PPI (180 events).
  3. *Employment & Labor:* Initial Jobless Claims (weekly), NFP, JOLTS (380 events).
  4. *Economic Growth & Spending:* Advance/Final GDP, Retail Sales (120 events).
  5. *Forward PMIs & Sentiment:* ISM Manufacturing/Services, UMich Sentiment (300 events).
- **Total Event Windows on 15m Chart:** $1,180 \text{ events} \times 5 \text{ candles} = 5,900 \text{ active bars}$.

### 4.2 Standardized Macro Surprise Score ($Z$)
- Following Kurov et al. (JFQA, 2018):
  $$Z_{i, t} = \frac{A_{i, t} - F_{i, t}}{\sigma_i}$$
  where $A$ is Actual, $F$ is Consensus Forecast, and $\sigma$ is the historical standard deviation of surprises for indicator $i$.

### 4.3 The Continuous Countdown Clock Feature
$$\text{minutes\_to\_next\_news} = \frac{\min(t_{\text{next\_event}} - t, 1440)}{60} \in [0.0, 24.0]$$
$$\text{is\_risk\_window}_t = \begin{cases} 1 & \text{if } |t - t_{\text{event}}| \le 30 \text{ minutes} \\ 0 & \text{otherwise} \end{cases}$$

### 4.4 High-Frequency Event Causality Verification
- Following Campbell, Lo, & MacKinlay (1997) and Corbet et al. (2020):
  Proves econometric causality by testing whether return variance $\sigma_{\text{event}}^2 > 3.0 \times \sigma_{\text{normal}}^2$ at $p < 0.001$ during $[-5\text{m}, +15\text{m}]$ release windows.

---

## Pillar 5: Post-Signal Trajectory Archetypes & Triple-Barrier Labeling

### 5.1 Rejection of Point-by-Point Forecasting
- Fama (1970) and Lo & MacKinlay (1988): Predicting exact candle wicks point-by-point compounds Brownian noise ($O(\sigma \sqrt{t})$). We formulate the problem as **Path Signature / Trajectory Classification**.

### 5.2 The Three Canonical Trajectory Archetypes ($H=8$ Bars / 2 Hours)
For a candidate signal fired at bar $t$ with entry price $P_t$ and volatility $\sigma_t = \text{ATR}_{14}(t)$:

```
Trajectory Archetype 1: Clean Impulse Expansion (Target Win)
  • Upper Barrier Hit: Price reaches P_t + 2.0 * sigma_t
  • Max Retracement: Retraces less than 0.5 * sigma_t before hitting TP.
  • Action: Market Order Execution (2:1 R:R).

Trajectory Archetype 2: Deep Liquidity Sweep / Retest (Smart Money Re-Entry)
  • Retracement Sweep: Price sweeps between -0.75 * sigma_t and -1.25 * sigma_t.
  • Reversal: Violently rejects the stop line and reaches +2.0 * sigma_t.
  • Action: Limit Order Placement at CE Stop / VWAP Level.

Trajectory Archetype 3: Mean-Reversion Collapse (Chop / False Breakout)
  • Lower Barrier Hit: Price penetrates through -1.0 * sigma_t without expanding.
  • Stagnation: Price expires below entry hurdle after 8 bars.
  • Action: Complete Trade Abstention (Zero Risk).
```

### 5.3 Formal Triple-Barrier Definition (López de Prado, 2018)
$$y_t = \begin{cases} 1 & \text{if Clean Expansion (Archetype 1)} \\ 2 & \text{if Sweep Retest (Archetype 2)} \\ 0 & \text{if Collapse / Abstain (Archetype 3)} \end{cases}$$

---

## Pillar 6: Few-Shot Metric Embedding Network (The Oxford Extension)

### 6.1 Multi-Modal Input Vector ($\mathbf{x}_t \in \mathbb{R}^8$)
1. `minutes_to_news`: Normalized distance to upcoming macro release.
2. `is_news_risk_zone`: Binary flag for $\pm 30\text{m}$ event boundary.
3. `surprise_z`: Standardized economic surprise score.
4. `bar_delta_norm`: Taker Buy Volume minus Taker Sell Volume divided by ATR.
5. `cvd_slope_4`: 4-bar slope of Cumulative Volume Delta.
6. `whale_delta_ratio`: Taker volume $>1\text{ BTC}$ relative to retail noise.
7. `vwap_distance_norm`: Normalized distance from price to Session VWAP.
8. `ce_distance_norm`: Normalized distance from price to Chandelier Exit stop.

### 6.2 Metric Projection Architecture ($f_\theta: \mathbb{R}^8 \to \mathbb{R}^{16}$)
- Layer 1: Linear($8 \to 32$) + LayerNorm + LeakyReLU($0.1$) + Dropout($0.2$)
- Layer 2: Linear($32 \to 32$) + LayerNorm + LeakyReLU($0.1$) + Dropout($0.2$)
- Layer 3: Linear($32 \to 16$) $\to$ Latent representation $\mathbf{z}_t = f_\theta(\mathbf{x}_t)$.

### 6.3 Prototypical Class Centroids & Distance Softmax
Following Snell, Swersky, & Zemel (NeurIPS) and Wood et al. (2024):
- For support set $S_k$ of class $k \in \{0, 1, 2\}$:
  $$\mathbf{c}_k = \frac{1}{|S_k|} \sum_{\mathbf{x}_i \in S_k} f_\theta(\mathbf{x}_i)$$
- Distance to class prototypes:
  $$d_k(\mathbf{x}_q) = ||f_\theta(\mathbf{x}_q) - \mathbf{c}_k||_2$$
- Class probability distribution:
  $$P(y = k \mid \mathbf{x}_q) = \frac{\exp(-d_k(\mathbf{x}_q))}{\sum_{j \in \{0, 1, 2\}} \exp(-d_j(\mathbf{x}_q))}$$

### 6.4 Conformal Trade-Abstention Gatekeeper
$$\text{If } \min_k d_k(\mathbf{x}_q) > \tau_{\text{novelty}} \quad \text{OR} \quad P(y = 0 \mid \mathbf{x}_q) \ge 0.40 \implies \mathbf{ABSTAIN}$$

---

## Pillar 7: Asymmetric Loss Formulations & Prop-Firm Barrier Objectives

### 7.1 The Differentiable Sharpe Ratio Objective (Wood et al., 2024)
$$\mathcal{L}_{\text{Sharpe}} = -\frac{\frac{1}{T}\sum_{t=1}^T R_t}{\sqrt{\frac{1}{T}\sum_{t=1}^T R_t^2 - \left(\frac{1}{T}\sum_{t=1}^T R_t\right)^2}}$$
$$R_t = z_t \cdot r_{t+1} - c \cdot |z_t - z_{t-1}|$$

### 7.2 Asymmetric Prop-Firm Barrier Loss
In proprietary trading, suffering a maximum daily drawdown (-4%) results in instant account termination. False positive trade errors must be penalized asymmetrically:
$$\mathcal{L}_{\text{total}} = -\sum_{k} w_k \cdot y_k \log(\hat{p}_k) + \lambda_{\text{DD}} \cdot \max(0, \text{Drawdown}_t - 0.03)^2$$
- Penalty Weights: $w_{\text{collapse}} = 3.0, w_{\text{sweep}} = 1.0, w_{\text{expansion}} = 1.5$.
- Enforces extreme caution: misclassifying a Collapse as a Clean Expansion incurs a $3\times$ heavier gradient penalty.

---

## Pillar 8: Combinatorial Purged Cross-Validation & Falsification Rigor

### 8.1 Combinatorial Purged Cross-Validation (CPCV)
- Reference: Marcos López de Prado (*Advances in Financial Machine Learning*, Chapter 12; ISLR p. 184).
- Setup: $N=6$ chronological historical blocks, $k=2$ test blocks.
- Yields $\binom{6}{2} = 15$ distinct out-of-sample backtest paths.
- **Purging & Embargoing:** Drops all bars within 8 bars before or after block transitions to ensure zero lookahead or label overlap leakage.

### 8.2 Institutional Friction Deductions
Every backtested execution strictly deducts:
- **Taker Fee:** $0.04\%$ on market entries (Clean Expansions).
- **Maker Fee:** $0.02\%$ on passive limit fills (Sweep Retests).
- **Slippage:** $1$ tick ($\$0.50$ on BTC) on all stop-loss barrier touches.

### 8.3 Deflated Sharpe Ratio (DSR) Multi-Testing Correction
- Reference: Bailey & López de Prado (Journal of Portfolio Management, 2014).
- Calculates the probability that the observed Sharpe ratio is a statistical false discovery:
  $$\text{DSR} = \Phi\left( \frac{(\widehat{\text{SR}} - \text{SR}^*) \sqrt{T-1}}{\sqrt{1 - \hat{\gamma}_3 \widehat{\text{SR}} + \frac{\hat{\gamma}_4 - 1}{4}\widehat{\text{SR}}^2}} \right)$$
- Preregistered Acceptance Threshold: $p < 0.01$.

### 8.4 Synthetic Target Shuffling Permutation Test
- The target trajectory labels $y$ are randomly permuted 100 times while keeping the feature matrix identical.
- **Falsification Gate:** On scrambled labels, the model's Sharpe ratio must collapse to $\text{SR} \le 0.0$. If the model shows profitability on scrambled data, the pipeline is immediately rejected for lookahead leakage.

---

## Formal Revision Sign-off Matrix

- [x] **Pillar 1:** Research Epistemology & Formal Hypotheses
- [x] **Pillar 2:** Primary Heuristic Trigger (CE + Session VWAP)
- [x] **Pillar 3:** Microstructure & Order Flow Delta Formulations
- [x] **Pillar 4:** Point-in-Time 1,180 Macro News Event Matrix
- [x] **Pillar 5:** 3 Trajectory Archetypes & Triple-Barrier Labeling
- [x] **Pillar 6:** Few-Shot Prototypical Metric Architecture
- [x] **Pillar 7:** Asymmetric Prop-Firm Barrier Loss
- [x] **Pillar 8:** Combinatorial Purged Cross-Validation (CPCV) & DSR
