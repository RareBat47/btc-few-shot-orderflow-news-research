# Day 1: Deep Decomposition of the Oxford Base Paper (Wood et al., 2024)

**Document Type:** Research Apprenticeship Lecture & Paper Analysis Dossier  
**Topic 1.1:** Financial Time-Series Non-Stationarity & Why Standard Deep Learning Fails in Crashes  
**Base Paper:** Wood, Kessler, Roberts, & Zohren (Oxford-Man Institute, *JFDS* 2024 / arXiv:2310.10500)  
**Primary Architecture:** X-Trend (Cross-Attentive Time-Series Trend Network)  

---

## 1. Bibliographic Identity & Context
- **Title:** Few-Shot Learning Patterns in Financial Time-Series for Trend-Following Strategies
- **Authors:** Kieran Wood, Samuel Kessler, Stephen J. Roberts, Stefan Zohren
- **Affiliation:** Oxford-Man Institute of Quantitative Finance, Department of Engineering Science, University of Oxford
- **Publication:** *The Journal of Financial Data Science*, Vol. 6, Issue 2 (Spring 2024), pp. 88–115
- **DOI:** `10.3905/jfds.2024.1.157` | **arXiv:** `2310.10500`
- **Data Examined in Paper:** 50 continuous commodity, equity index, fixed income, and FX futures contracts spanning 1990 to 2023.

---

## 2. The Core Problem: The Failure of Empirical Risk Minimization (ERM)

In standard machine learning (e.g., Computer Vision or NLP), models rely on the **I.I.D. Assumption** (Independent and Identically Distributed):
$$P_{\text{train}}(X, y) \approx P_{\text{test}}(X, y)$$
A cat in a training photo looks like a cat in a test photo. The underlying probability distribution does not change.

### The Financial Non-Stationarity Breakdown
Financial time series are **strictly non-stationary**. The joint distribution of market features $X$ and forward returns $y$ changes continuously over time:
$$P_t(X, y) \neq P_{t + \Delta t}(X, y)$$

When a quantitative firm trains a deep learning model (e.g., an LSTM or Deep Momentum Network) using standard **Empirical Risk Minimization (ERM)** over a 3-year historical window ($t_0 \to t_1$), the model optimizes weights $\theta$ to minimize historical loss:
$$\theta^* = \arg\min_\theta \frac{1}{N} \sum_{i=1}^N \mathcal{L}(f_\theta(X_i), y_i)$$

### The March 2020 COVID-19 Case Study (Why Standard Models Bleed)
Wood et al. highlight the real-world collapse of systematic trend-following funds during February–March 2020:
1. **The Pre-Crash Regime (2017–2019):** Characterized by low volatility, steady upward drift, and shallow, buyable pullbacks. The neural network learns that *"any price dip with mild negative momentum is a buying opportunity."*
2. **The Structural Shock (March 2020):** COVID-19 lockdowns hit. Volatility spikes by $400\%$ in days (VIX surges from 15 to 82). The Dow Jones plunges 6,400 points in 4 trading days.
3. **The Fatal ERM Failure:** The static model encounters a market state that never existed in its 3-year training window. Because its weights $\theta^*$ were trained to buy dips, **it continues buying aggressively as prices collapse**, taking massive, fund-threatening drawdowns.
4. **The Slow Retraining Bottleneck:** Standard models require hundreds of new training samples to gradient-update their weights. By the time an LSTM or Transformer has seen enough crash bars to learn the new regime, the fund has already suffered maximum drawdown or liquidation.

---

## 3. The Objective Function in Wood et al. (Differentiable Sharpe Ratio)

Unlike computer vision models that optimize Cross-Entropy or Mean Squared Error, Wood et al. train the network directly on an approximation of the annualized **Sharpe Ratio** of returns:

Let $z_t \in [-1, 1]$ be the position output by the model at time $t$, and $r_{t+1}$ be the realized asset return. The strategy return is:
$$R_t = z_t \cdot r_{t+1} - c \cdot |z_t - z_{t-1}|$$
where $c$ is the transaction cost fee.

The Sharpe Ratio over horizon $T$ is:
$$\text{Sharpe} = \frac{\mathbb{E}[R]}{\sqrt{\text{Var}(R)}} \approx \frac{\frac{1}{T} \sum_{t=1}^T R_t}{\sqrt{\frac{1}{T} \sum_{t=1}^T R_t^2 - \left(\frac{1}{T} \sum_{t=1}^T R_t\right)^2}}$$

The authors use the negative Sharpe ratio as their loss function:
$$\mathcal{L}_{\text{Sharpe}} = -\text{Sharpe}(R_{1:T})$$

### The Mathematical Insight:
By making the Sharpe ratio differentiable, the neural network learns to penalize volatility and portfolio turnover directly in the gradient update. However, when an unprecedented regime shift occurs, $\text{Var}(R)$ blows up, causing gradient instability.

---

## 4. The Oxford Solution: Few-Shot Pattern Conditioning

To prevent catastrophic drawdown during shocks without waiting months to retrain, Wood et al. propose **X-Trend**:
- Instead of learning static weights, the network is conditioned on a **Context Set (Support Set)** of $K$ past regime patterns.
- When an unexpected shock occurs, the model uses a **Cross-Attention Mechanism** to search its memory for historical analogues (e.g., the 2008 Lehman collapse or the 2001 dot-com bust) and immediately adapts its position sizing in the new regime.

---

## 5. Daily Apprenticeship Log & Concept Check

- **Verified Concept:** Financial non-stationarity breaks standard gradient descent (ERM).
- **Core Mechanism Understood:** The difference between static retraining (slow, loss-making) vs. few-shot context conditioning (instantaneous adaptation).
- **Next Topic (Day 2):** Dissecting the Cross-Attention tensor mathematics ($\text{Softmax}(QK^T / \sqrt{d_k})V$) and Change-Point Detection.
