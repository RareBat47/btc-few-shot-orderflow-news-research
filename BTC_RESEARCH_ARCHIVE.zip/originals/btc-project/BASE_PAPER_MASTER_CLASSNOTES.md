# Master Classnotes & Study Guide: The Oxford Base Paper

**Paper Title:** Few-Shot Learning Patterns in Financial Time-Series for Trend-Following Strategies  
**Authors:** Kieran Wood, Samuel Kessler, Stephen J. Roberts, Stefan Zohren  
**Institution:** Oxford-Man Institute of Quantitative Finance, University of Oxford  
**Publication:** *The Journal of Financial Data Science* (JFDS), Vol. 6, Issue 2, pp. 88–115 (2024)  
**ArXiv Reference:** `arXiv:2310.10500`  
**Study Guide Author:** Research Apprenticeship Mentor  
**Target Student:** Arifin Nabid (Principal Investigator)  

---

## Table of Contents
1. [The Big Idea (The 30-Second Intuition)](#1-the-big-idea-the-30-second-intuition)
2. [The Core Problem: Why Standard Trading AIs Blow Up in Crashes](#2-the-core-problem-why-standard-trading-ais-blow-up-in-crashes)
3. [Step 1: Slicing Market History into "Regimes" (Change-Point Detection)](#3-step-1-slicing-market-history-into-regimes-change-point-detection)
4. [Step 2: The Core Architecture — X-Trend Explained](#4-step-2-the-core-architecture--x-trend-explained)
5. [The Mathematics of Cross-Attention (Plain English + Equations)](#5-the-mathematics-of-cross-attention-plain-english--equations)
6. [The Loss Function: Making the Sharpe Ratio Differentiable](#6-the-loss-function-making-the-sharpe-ratio-differentiable)
7. [The Experiment: 50 Futures Markets Across 33 Years](#7-the-experiment-50-futures-markets-across-33-years)
8. [The Actual Results: Did It Beat the Market?](#8-the-actual-results-did-it-beat-the-market)
9. [The Code Mechanics: How the PyTorch Model Runs](#9-the-code-mechanics-how-the-pytorch-model-runs)
10. [The Flaws of the Paper (Our Scientific Research Gap)](#10-the-flaws-of-the-paper-our-scientific-research-gap)
11. [Student Quick-Review & Exam Cheat Sheet](#11-student-quick-review--exam-cheat-sheet)

---

## 1. The Big Idea (The 30-Second Intuition)

Imagine a seasoned human hedge fund trader who has traded through the **2000 Dot-Com crash**, the **2008 Lehman Brothers collapse**, and the **2020 COVID-19 panic**.

When a sudden crisis hits the market, that human trader does **not** sit down and spend three weeks reading textbooks from scratch to figure out what to do. Instead, the trader thinks:
> *"Wait, this price action and panic volume looks almost identical to what happened in October 2008. In 2008, dip-buying got destroyed, but shorting violent bounces worked. I will trade this like 2008."*

Standard Machine Learning models (like LSTMs or standard Transformers) **cannot do this**. They have no memory bank of distinct historical eras. They just have static mathematical weights that get completely confused when a rare crisis happens.

**What the Oxford researchers did:** They built an AI architecture called **X-Trend**. Instead of relying on static weights, X-Trend carries a **memory bank of past historical market regimes** and uses an attention mechanism to search that memory bank in real time. If today's market looks like a past crash, it borrows the winning strategy from that past crash instantly—without needing to be retrained.

---

## 2. The Core Problem: Why Standard Trading AIs Blow Up in Crashes

### 2.1 The Lie of "I.I.D." Data
In standard computer science machine learning (like image recognition or ChatGPT):
- A cat picture in 2020 has the same pixels and structure as a cat picture in 2026.
- The data is **I.I.D.** (*Independent and Identically Distributed*). The training rules stay valid forever.

In financial trading, this assumption is completely **false**. Financial markets are **strictly non-stationary**:
$$P_{\text{train}}(\text{Price}, \text{Returns}) \neq P_{\text{future}}(\text{Price}, \text{Returns})$$

### 2.2 The March 2020 COVID Crash Case Study
The authors demonstrate this failure using the March 2020 COVID panic:
1. **The 2017–2019 Bull Run:** For three years, market volatility was low, and markets steadily drifted upward. Any small price dip was followed by a bounce.
2. **What the AI Learned:** The neural network optimized its internal weights to believe: *"Whenever price dips slightly below the moving average, buy aggressively."*
3. **The Black Swan:** In March 2020, global lockdowns caused the Dow Jones to drop 6,400 points in 4 days.
4. **The Disaster:** Because the AI's weights were trained to buy dips, it kept buying the crash all the way down, suffering maximum account drawdowns.
5. **The Retraining Trap:** Deep neural networks need hundreds of new data points to gradient-descend their weights into a new regime. By the time a normal model realizes the market is crashing, the fund is already liquidated.

---

## 3. Step 1: Slicing Market History into "Regimes" (Change-Point Detection)

You cannot compare today's market to the past if your past data is just one giant, continuous, unorganized price chart. You must organize history into **discrete chapters (regimes)**.

### Why Calendar Months Don't Work
Splitting data by "January 2020", "February 2020", etc., is unscientific. The market does not care about human calendar dates. A crash regime can last 12 days, while a summer chop regime can last 4 months.

### The Solution: Bayesian Online Change-Point Detection (BOCPD)
The authors run a statistical algorithm called **Change-Point Detection** over historical returns:
- It tracks the probability that the current price bar came from the same statistical distribution (mean return and volatility) as prior bars.
- When volatility or directional velocity suddenly explodes, the algorithm flags a **Change-Point**:
  $$\text{Regime } r_i = [t_{\text{start}}, t_{\text{end}}]$$
- **Result:** 33 years of futures history is segmented into a clean catalog of distinct regimes:
  - *Calm Trend Regimes*
  - *Violent Liquidation Regimes*
  - *Sideways Choppy Regimes*

These segmented regimes become the **Context Set (Memory Bank)** used by the AI.

---

## 4. Step 2: The Core Architecture — X-Trend Explained

X-Trend stands for **Cross-Attentive Time-Series Trend Network**. It consists of three main engines:

```
┌───────────────────────────────────────────────────────────────┐
│               1. THE CONTEXT SET (MEMORY BANK)                │
│    A curated library of K historical market regime blocks     │
│    [Regime 1: 2008 Crash] [Regime 2: 2017 Bull] [Regime 3...] │
└───────────────────────────────┬───────────────────────────────┘
                                │
                                ▼ Encoded into Key/Value Vectors
┌───────────────────────────────┴───────────────────────────────┐
│                  2. THE CROSS-ATTENTION CORE                  │
│                                                               │
│   Query (Q): What today's market looks like right now         │
│   Keys  (K): What each historical regime looked like          │
│   Values(V): What trading positions won in those regimes      │
│                                                               │
│   Cross-Attention calculates similarity:                      │
│   "Today is 80% similar to 2008 Crash, 10% to 2017 Bull"      │
└───────────────────────────────┬───────────────────────────────┘
                                │
                                ▼ Weighted Combination
┌───────────────────────────────┴───────────────────────────────┐
│                  3. THE POSITION OUTPUT LAYER                 │
│   Outputs continuous position sizing: z_t in [-1.0, +1.0]     │
│   (-1.0 = Max Short, 0.0 = Flat Cash, +1.0 = Max Long)        │
└───────────────────────────────────────────────────────────────┘
```

---

## 5. The Mathematics of Cross-Attention (Plain English + Equations)

In a standard Transformer (like ChatGPT), the model uses **Self-Attention** (words in a sentence look at other words in the *same* sentence).

In X-Trend, the authors use **Cross-Attention**: the current market looks across at a completely *different* set of historical data.

### The Core Formula:
$$\text{Attention}(Q, K, V) = \text{softmax}\left(\frac{Q K^T}{\sqrt{d_k}}\right) V$$

Let's break down each letter in plain English:

- **$Q$ (The Query):** A vector describing the current target regime (the last few bars of today's market). Think of this as the **search query** you type into Google.
- **$K$ (The Keys):** Vectors describing the signature of every historical regime in the memory bank. Think of these as the **titles of web pages** Google is searching through.
- **$Q K^T$ (The Dot Product):** This measures how similar today's market is to each historical regime. If today's vector points in the same direction as the 2008 crash vector, the result is a huge positive number.
- **$\sqrt{d_k}$ (The Scaling Factor):** Divides by the square root of the vector dimension to keep numbers from blowing up into infinity.
- **$\text{softmax}(\cdot)$:** Converts those similarity scores into clean percentages that add up to $100\%$ (e.g., $75\%$ 2008 Crash, $15\%$ 2015 Chop, $10\%$ 2020 Rebound).
- **$V$ (The Values):** The actual profitable trading actions that worked during those past regimes.
- **The Output:** The model multiplies the percentages by the Values. It outputs a trading position tailored to the regime it recognized!

---

## 6. The Loss Function: Making the Sharpe Ratio Differentiable

Most amateur AI projects train models using **Mean Squared Error (MSE)** (trying to predict the exact price tomorrow). 

Wood et al. reject MSE because **predicting price numbers does not mean you make money.** A model can predict prices accurately on calm days, but blow up your account on one bad trade.

### The Objective: Maximize the Sharpe Ratio
The authors train the model to directly maximize the **Sharpe Ratio** (Return divided by Volatility):
$$\text{Sharpe} = \frac{\mathbb{E}[R]}{\sigma_R}$$

Where the daily strategy return $R_t$ from taking position $z_t \in [-1, 1]$ on asset return $r_{t+1}$ with transaction fee $c$ is:
$$R_t = z_t \cdot r_{t+1} - c \cdot |z_t - z_{t-1}|$$

### The Loss Function:
$$\mathcal{L} = -\text{Sharpe}(R_{1:T}) = -\frac{\frac{1}{T}\sum_{t=1}^T R_t}{\sqrt{\frac{1}{T}\sum_{t=1}^T R_t^2 - \left(\frac{1}{T}\sum_{t=1}^T R_t\right)^2}}$$

**Why this is brilliant:**
Because the equation is fully differentiable, backpropagation forces the neural network to:
1. Maximize profitable trends.
2. Severely punish volatile wild swings in equity.
3. Minimize unnecessary over-trading (because the fee term $c \cdot |z_t - z_{t-1}|$ reduces the Sharpe ratio).

---

## 7. The Experiment: 50 Futures Markets Across 33 Years

To prove this wasn't just curve-fitted luck on one stock, the Oxford team ran a massive, institutional-scale backtest:

- **Data Universe:** 50 highly liquid continuous futures contracts.
- **Asset Classes:** Commodities (Crude Oil, Gold, Wheat), Equity Indices (S&P 500, FTSE, DAX), Government Bonds (US 10-Year, Bund), and Currencies (EUR, JPY, GBP).
- **Time Horizon:** 1990 to 2023 (33 years of data covering the Gulf War, Dot-Com Bust, 2008 Financial Crisis, 2016 Trump election, and 2020 COVID).
- **The Baselines They Beat:**
  1. *TSMOM (Time-Series Momentum):* The classical Moskowitz et al. (2012) trend-following benchmark used by billion-dollar CTA funds.
  2. *DMN (Deep Momentum Network):* A modern LSTM-based deep learning trading system.
  3. *Static Neural Forecasters:* Standard Transformer models without few-shot cross-attention.

---

## 8. The Actual Results: Did It Beat the Market?

The experimental results published in *The Journal of Financial Data Science* established new state-of-the-art benchmarks:

- **+18.9% Sharpe Ratio Boost:** X-Trend achieved an 18.9% higher risk-adjusted return than the best neural forecaster during the chaotic 2018–2023 out-of-sample testing period.
- **10-Fold Outperformance over Classic CTA Momentum:** Demolished the traditional rule-based TSMOM strategy (which suffered severe whipsaws during post-2020 inflation swings).
- **2x Faster Recovery from Drawdown:** During the March 2020 COVID crash, while standard neural models took over 180 days to recover their lost equity, X-Trend recognized the shock pattern and recovered in under 90 days.
- **Zero-Shot Asset Transfer (5-Fold Gain):** When tested on brand-new financial instruments it had *never* trained on, X-Trend achieved a 5-fold Sharpe ratio increase over baseline models by matching cross-asset patterns.

---

## 9. The Code Mechanics: How the PyTorch Model Runs

The authors implemented X-Trend in **PyTorch** running on an NVIDIA RTX 3090 GPU:

### Tensor Dimensions Inside the Attention Layer:
1. **Target Regime Input ($Q$):** Shape `[Batch_Size, Target_Seq_Len, Features]`
   - e.g., `[32, 21, 6]` (32 batches of 21-day target windows with 6 normalized price/volatility features).
2. **Context Set Input ($K, V$):** Shape `[Batch_Size, Num_Regimes * Context_Seq_Len, Features]`
   - e.g., `[32, 5 * 21, 6]` (5 historical regimes of 21 days each).
3. **Cross-Attention Output:** Shape `[32, 21, Hidden_Dim]`
   - Projects the attended context into a dense representation.
4. **Final Linear Head:** Uses a $\tanh$ activation function to squeeze outputs into $[-1.0, +1.0]$:
   $$\text{Position } z_t = \tanh(\mathbf{W} \cdot \mathbf{h}_t + b)$$

---

## 10. The Flaws of the Paper (Our Scientific Research Gap)

To publish a Q1 paper of our own, we must identify what Oxford left unsolved. Wood et al. has **three massive, glaring limitations**:

### Gap 1: It is Completely Blind to Order Flow Microstructure
- **The Flaw:** The authors only used macroscopic daily closing prices. They had zero visibility into *who* was moving the market.
- **Why this hurts them:** On intraday timeframes (like 15m), a candle can close green purely because of low liquidity, while aggressive sellers are actually dumping behind the scenes.
- **Our Fix:** We inject **Binance Centralized Taker Buy/Sell Delta and CVD**, giving the model real-time visibility into aggressive vs. passive order flow.

### Gap 2: It is Completely Blind to Economic News Clocks
- **The Flaw:** X-Trend treats every day equally. It does not know if today is an ordinary quiet Tuesday or an FOMC Interest Rate Decision day.
- **Why this hurts them:** Trailing stops get annihilated during news releases due to artificial spread widening.
- **Our Fix:** We integrate a deterministic countdown clock (`minutes_to_news`) to enforce an automated risk-off shield before scheduled volatility bombs.

### Gap 3: Unstructured Execution (No Stop-Loss or Take-Profit)
- **The Flaw:** X-Trend outputs a floating continuous number ($z_t \in [-1, 1]$). It has no concept of a hard stop-loss, no profit targets, and no asymmetric Risk:Reward structuring.
- **Why this hurts them:** It cannot be deployed on a prop-firm account with strict daily drawdown limits (e.g., 4% max loss).
- **Our Fix:** We anchor the engine to the **Chandelier Exit** with an asymmetric **2:1 Risk-to-Reward ratio** and classify post-signal paths into **3 Trajectory Archetypes** (Clean Expansion, Sweep Retest, Collapse).

---

## 11. Student Quick-Review & Exam Cheat Sheet

- **What does X-Trend stand for?** Cross-Attentive Time-Series Trend Network.
- **Who wrote it?** Kieran Wood & Stefan Zohren (Oxford-Man Institute, Oxford University, 2024).
- **What is the core problem it solves?** Traditional AI trading models blow up during sudden market crashes because they rely on static weights and retrain too slowly.
- **What is the core mechanism?** Slicing history into regime blocks via Change-Point Detection, storing them in a Context Set, and using Transformer Cross-Attention to match today's market to historical crash analogues.
- **What loss function did it use?** Negative Differentiable Sharpe Ratio (penalizes volatility and transaction fees directly in the gradient).
- **What was its biggest performance win?** +18.9% Sharpe ratio improvement and 2x faster recovery from the COVID-19 crash.
- **What did it fail to do?** It had no order flow, no economic news calendar timing, and no intraday stop-loss/take-profit structure. That is what our research solves.
