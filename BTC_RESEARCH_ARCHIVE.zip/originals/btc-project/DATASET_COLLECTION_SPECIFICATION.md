# Dataset Collection & Feature Engineering Specification

**Document Identifier:** SPEC-DATA-BTC-15M-2026-V1  
**Project:** Few-Shot Trajectory Archetype Prediction in Intraday Bitcoin  
**Repository:** `/home/rarebat/PORTFOLIO/Signal/BTC/`  
**Target Manuscript:** *The Journal of Financial Data Science* (JFDS) / *Quantitative Finance*  
**Principal Investigator:** Arifin Nabid  
**Research Mentor:** Research Apprenticeship Mentor & Systems Researcher  

---

## 1. Unified Dataset Architecture

To train our Few-Shot Metric Network and ensure our empirical evaluation survives Q1 peer review, our dataset must integrate three distinct, synchronized data streams with **zero lookahead bias**:

```
┌────────────────────────────────────────────────────────────────────────┐
│                      UNIFIED MULTI-MODAL DATASET                       │
├────────────────────────────────────────────────────────────────────────┤
│ STREAM 1: Microstructure Order Flow & Price History (Binance Vision)  │
│ • Source: Binance USDT-M Perpetual Futures (`BTCUSDT`, `ETHUSDT`)     │
│ • Granularity: 15-Minute Klines with Taker Buy Volume (5+ Years)       │
│ • Role: Substrate for Chandelier Exit signals + Order Flow Delta      │
├────────────────────────────────────────────────────────────────────────┤
│ STREAM 2: Derivatives Market Positioning Metrics (Binance Metrics)     │
│ • Source: Binance Daily / 5m Public Metrics Archives                   │
│ • Granularity: Synchronized point-in-time to 15m bar close             │
│ • Role: Identifies institutional vs. retail leverage imbalances        │
├────────────────────────────────────────────────────────────────────────┤
│ STREAM 3: Point-in-Time US Macroeconomic Announcements & Clocks        │
│ • Source: High-impact release schedule (1,030+ events 2021-2026)       │
│ • Granularity: Minute-level timestamps + Surprise Z-scores             │
│ • Role: Continuous pre-event countdown clocks & volatility conditioning│
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Stream 1: Binance USDT-M 15m Klines & Order Flow Microstructure

### 2.1 Public Data Provenance
- **Archive URL:** `https://data.binance.vision/data/futures/um/monthly/klines/BTCUSDT/15m/`
- **History Range:** January 1, 2021 to March 31, 2026 (63 months continuous).
- **Total Candle Count:** $\approx 184,000$ consecutive 15-minute candles.
- **Cost & Access:** 100% Free, public ZIP archives, downloadable via script with zero API keys required.

### 2.2 Raw Schema Fields
Every 15-minute CSV row in the Binance archive contains 12 deterministic columns:
1. `open_time`: Unix epoch in milliseconds (bar start).
2. `open`: First fill price of the 15m bar.
3. `high`: Highest executed trade price.
4. `low`: Lowest executed trade price.
5. `close`: Last fill price of the 15m bar.
6. `volume`: Total quantity of base asset (BTC) traded across all fills.
7. `close_time`: Unix epoch in milliseconds (bar close).
8. `quote_volume`: Total traded volume in USDT.
9. `count`: Number of individual matched trade fills (trade frequency).
10. `taker_buy_volume`: Total base asset volume executed by aggressive buyers who crossed the spread (market buy orders).
11. `taker_buy_quote_volume`: Total USDT volume executed by aggressive buyers.
12. `ignore`: Reserved field.

### 2.3 Derived Microstructure Formulas
From these raw fields, we compute deterministic order flow metrics:
- **Aggressive Buyer Volume ($V_{\text{buy}}$):**
  $$V_{\text{buy}, t} = \text{taker\_buy\_volume}_t$$
- **Aggressive Seller Volume ($V_{\text{sell}}$):**
  $$V_{\text{sell}, t} = \text{volume}_t - \text{taker\_buy\_volume}_t$$
- **Net Bar Order Flow Delta ($\text{Delta}_t$):**
  $$\text{Delta}_t = V_{\text{buy}, t} - V_{\text{sell}, t} = 2 \times \text{taker\_buy\_volume}_t - \text{volume}_t$$
- **Cumulative Volume Delta (CVD) Momentum ($\text{CVD}_{4, t}$):**
  $$\text{CVD}_{4, t} = \sum_{i=0}^3 \text{Delta}_{t-i}$$
  *(Measures the net aggressive buying/selling pressure over the preceding 1 hour).*
- **Normalized Delta Aggression ($\text{Delta}_{\text{norm}, t}$):**
  $$\text{Delta}_{\text{norm}, t} = \frac{\text{Delta}_t}{\text{volume}_t} \in [-1.0, +1.0]$$
- **Passive Absorption Divergence ($\text{Absorption}_t$):**
  $$\text{Absorption}_t = \begin{cases} +1 & \text{if } \text{Close}_t > \text{Close}_{t-1} \text{ and } \text{Delta}_t < 0 \quad (\text{Smart Money Absorbing Buying}) \\ -1 & \text{if } \text{Close}_t < \text{Close}_{t-1} \text{ and } \text{Delta}_t > 0 \quad (\text{Smart Money Absorbing Selling}) \\ 0 & \text{otherwise} \end{cases}$$
- **Average Trade Size Proxy ($\text{ATS}_t$):**
  $$\text{ATS}_t = \frac{\text{volume}_t}{\text{count}_t}$$
  *(A spike in ATS indicates institutional large-lot block trading; small ATS indicates retail churn).*

---

## 3. Stream 2: Binance Derivatives Positioning & Leverage Metrics

### 3.1 Public Data Provenance
- **Archive URL:** `https://data.binance.vision/data/futures/um/daily/metrics/BTCUSDT/`
- **Granularity:** Aggregated 5-minute / daily snapshots.

### 3.2 Key Positioning Fields
1. `sum_open_interest`: Total active open contracts in BTC.
2. `sum_open_interest_value`: Total active exposure in USDT.
3. `top_trader_long_short_ratio`: Ratio of long positions to short positions held by the top 20% margin accounts on Binance.
4. `long_short_ratio`: Global account long/short sentiment (heavily weighted toward retail).

### 3.3 Engineered Regime Features
- **$\Delta \text{OI}_{24\text{h}}$ Expansion:**
  $$\Delta \text{OI}_{t} = \frac{\text{OI}_t - \text{OI}_{t-96}}{\text{OI}_{t-96}}$$
  *(Differentiates true fresh trend accumulation ($\Delta \text{OI} > 0$) from short-covering rallies ($\Delta \text{OI} < 0$)).*
- **Institutional vs. Retail Sentiment Divergence:**
  $$\text{Sentiment\_Divergence}_t = \text{TopTrader}_{L/S, t} - \text{Global}_{L/S, t}$$
  *(Positive values indicate elite accounts are net long while retail is trapped short).*

---

## 4. Stream 3: Point-in-Time US Macroeconomic Announcements

### 4.1 Event Universe Coverage (1,030+ Events)
- **Local Base File:** `/home/rarebat/PORTFOLIO/Signal/BTC/calendar_us_2021_2026.csv`
- **Target Expansion:** Expanded to the full 1,030+ high and medium impact US releases:
  1. FOMC Decisions & Fed Chair Speeches
  2. Consumer Price Index (CPI) & Core PCE
  3. Non-Farm Payrolls (NFP) & Weekly Jobless Claims
  4. Gross Domestic Product (GDP) & Retail Sales
  5. ISM Manufacturing & Services PMIs

### 4.2 Point-in-Time Features
- **Continuous Countdown Clock:**
  $$\text{minutes\_to\_next\_news} = \min(t_{\text{next\_event}} - t, 1440) \in [0, 1440]$$
- **High-Risk Volatility Window Flag:**
  $$\text{is\_risk\_window}_t = \begin{cases} 1 & \text{if } |t - t_{\text{event}}| \le 30 \text{ minutes} \\ 0 & \text{otherwise} \end{cases}$$
- **Standardized Macro Surprise Z-Score:**
  $$Z = \frac{\text{Actual} - \text{Forecast}}{\sigma_{\text{historical}}}$$
  *(Only populated strictly at or after $t_{\text{event}}$, preventing lookahead leakage).*

---

## 5. Stream 4: Target Trajectory Archetypes (Triple-Barrier Labels)

For every candidate signal where the Chandelier Exit flips direction at bar $t$:
We inspect the subsequent $H=8$ candles (2 hours) using the Triple-Barrier method:

- **Barrier Heights:**
  - $\text{Upper Barrier} = P_{\text{entry}} + 2.0 \times \text{ATR}_{14}(t)$
  - $\text{Lower Barrier} = P_{\text{entry}} - 1.0 \times \text{ATR}_{14}(t)$
  - $\text{Time Barrier} = t + 8 \text{ bars}$
- **Classification Output ($y \in \{0, 1, 2\}$):**
  - **Class 1 (Clean Expansion):** Price hits $+2.0\text{ATR}$ without retracing more than $0.5\text{ATR}$ $\to$ Market order target.
  - **Class 2 (Sweep & Retest):** Price retraces between $-0.75\text{ATR}$ and $-1.25\text{ATR}$ (sweeping the stop line), then reverses to hit $+2.0\text{ATR}$ $\to$ Limit order target.
  - **Class 0 (Collapse / Chop):** Price breaches $-1.0\text{ATR}$ or expires below entry hurdle $\to$ Trade abstention target.

---

## 6. Zero-Shot Cross-Asset Evaluation Dataset

To satisfy Reviewer 2 and prove our model is not overfitted to Bitcoin:
- **Primary Training & Validation Asset:** `BTCUSDT` Perpetual Futures (2021–2026).
- **Out-of-Sample Zero-Shot Test Assets:**
  - `ETHUSDT` Perpetual Futures (2021–2026, ~184,000 bars).
  - `SOLUSDT` Perpetual Futures (2021–2026, ~150,000 bars).
- **Zero-Shot Protocol:** The model trained on `BTCUSDT` will be evaluated directly on `ETHUSDT` and `SOLUSDT` without fine-tuning, exactly matching Wood et al.'s cross-asset evaluation.
