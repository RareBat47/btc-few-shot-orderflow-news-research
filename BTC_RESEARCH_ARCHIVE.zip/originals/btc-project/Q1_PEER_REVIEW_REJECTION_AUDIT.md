# Q1 Peer Review Rejection Audit & Scientific Novelty Defense

**Document Identifier:** AUDIT-Q1-BTC-REJECTION-2026-V1  
**Project:** Few-Shot Trajectory Archetype Prediction in Intraday Bitcoin  
**Target Manuscript:** *The Journal of Financial Data Science* (JFDS) / *Quantitative Finance* / *ACM ICAIF*  
**Investigator:** Arifin Nabid  
**Mentor:** Research Apprenticeship Mentor & Systems Researcher  

---

## Part 1: The Brutal Truth — How Reviewer 2 Will Reject This Paper

If we submit the paper written as: *"We took the Chandelier Exit, added Binance order flow delta and an economic calendar, and trained a Few-Shot model to trade Bitcoin,"* **it will be desk-rejected or rejected in Round 1.**

Here are the exact 5 rejection critiques a top-tier peer reviewer will write:

### Rejection Reason 1: The "Frankenstein Pipeline" / Engineering Recipe Trap
> *"The authors present an engineering assembly of known parts: Wood et al.'s X-Trend model + an off-the-shelf retail technical indicator (Chandelier Exit) + Binance volume delta + a public economic calendar. There is no new neural network architecture, no new loss derivation, and no new econometric theorem. This is applied software engineering, suitable for an industry blog or trading desk writeup, but lacks the theoretical novelty required for a Q1 journal."*
- **Literature Grounding:** *gap-analysis skill (`references/capability-vs-contribution-audit.md`)*: Composition of published components ($A + B + C$) is presumptively solved and rejected as a capability demonstration unless framed around a specific empirical measurement or failure-mode resolution.

### Rejection Reason 2: The Single-Asset Overfitting Attack
> *"The authors claim their few-shot model adapts to market regimes, yet they evaluate exclusively on a single speculative asset (BTCUSDT) over a short 5-year window. In quantitative finance, testing on a single asset cannot distinguish between true structural alpha and regime-specific data snooping (Bailey et al., 2014; White, 2000). Wood et al. benchmarked 50 continuous futures across 4 asset classes over 33 years. A single crypto pair is statistically underpowered."*

### Rejection Reason 3: The Execution Reality & Adverse Selection Attack
> *"The proposed strategy relies on a hybrid 50/50 market and limit order execution. However, passive limit orders suffer from severe adverse selection—they are preferentially filled when toxic flow continues against the position, and left unfilled when the market breaks out cleanly. In an un-simulated backtest without queue position modeling or live L2 book depth, the reported 2:1 and 4:1 Risk-to-Reward metrics are backtest mirages."*

### Rejection Reason 4: The Data Revision & Lookahead Leakage Attack
> *"The authors propose calculating macroeconomic surprise scores ($Z = (A - F)/\sigma$). However, initial release figures are frequently subject to post-release revisions. If the authors used revised historical data rather than point-in-time real-time releases, the model suffers from lookahead leakage. Furthermore, did the authors account for funding rate payments every 8 hours and exchange maintenance disconnects?"*

### Rejection Reason 5: The "Why Few-Shot?" Occam's Razor Trap
> *"Financial returns on 15m crypto have a signal-to-noise ratio below 2%. What evidence proves that the complex cross-attentive few-shot metric network justifies its parameter overhead? Does it meaningfully outperform a simple L1-regularized logistic regression or a rule-based trend filter after fees? If an ablation shows linear models perform comparably, the few-shot architecture is over-engineering financial noise."*

---

## Part 2: Why This CAN Be a Q1 Paper — What Scientific Novelty ACTUALLY Means

The reason you asked *"why do you think this will be a Q1? I'm not inventing anything actually here"* is because you have the common misconception that **Q1 papers must invent a brand-new neural network from scratch (like inventing the Transformer).**

In Computer Science and Quantitative Finance, **that is false.** Look at the 4 verified types of scientific contributions (*gap-analysis skill*):

```
┌────────────────────────────────────────────────────────────────────────┐
│                   THE 4 TYPES OF SCIENTIFIC CONTRIBUTIONS              │
├─────────────────────────┬──────────────────────────────────────────────┤
│ 1. New Method           │ Beats SOTA on an existing benchmark by       │
│                         │ solving a specific failure mode.             │
├─────────────────────────┼──────────────────────────────────────────────┤
│ 2. New Benchmark /      │ The FIRST rigorous measurement of an         │
│    Empirical Measurement│ unmeasured phenomenon (Gold Standard).       │
├─────────────────────────┼──────────────────────────────────────────────┤
│ 3. New Theory /         │ Proving WHY an established mechanism works   │
│    Explanation          │ or fails under new boundary conditions.      │
├─────────────────────────┼──────────────────────────────────────────────┤
│ 4. Systematic           │ Proving that an established industry belief  │
│    Falsification        │ is mathematically or empirically false.      │
└─────────────────────────┴──────────────────────────────────────────────┘
```

### What OUR Genuine Q1 Contribution Actually Is:

We are **NOT** submitting a paper saying: *"Look at our profitable AI trading bot."* (That gets rejected).

We are submitting a paper that makes **Three Legitimate Scientific Contributions**:

1. **Empirical Microstructure Contribution (Contribution Type 3):**  
   We prove that macroscopic few-shot regime adaptation models (like Oxford's X-Trend) **break down completely on intraday time series unless grounded in centralized taker order flow and deterministic macroeconomic clocks**. We demonstrate the exact mathematical mechanism: price-only attention matrices confuse retail liquidity sweeps with institutional breakouts.
2. **Methodological Reformulation (Contribution Type 1):**  
   We reformulate the mathematically intractable problem of multi-step candlestick point prediction into **Few-Shot Trajectory Archetype Classification**, establishing the first formal path-signature benchmark comparing metric few-shot spaces against standard static GBDTs.
3. **Rigorous Econometric Falsification (Contribution Type 4):**  
   We provide the first fee-adjusted, Combinatorial Purged Cross-Validation (CPCV) benchmark of retail ATR trailing exits on cryptocurrency derivatives, establishing baseline empirical boundaries under institutional fee drag.

---

## Part 3: The Reviewer Defense Protocol (Our 5 Countermeasures)

To completely disarm Reviewer 2, we build these 5 explicit defenses into our experimental design:

```
┌────────────────────────────────────────────────────────────────────────┐
│                     REVIEWER 2 DEFENSE PROTOCOL                        │
├─────────────────────────┬──────────────────────────────────────────────┤
│ REVIEWER ATTACK         │ OUR PRE-REGISTERED DEFENSE                   │
├─────────────────────────┼──────────────────────────────────────────────┤
│ 1. "Frankenstein        │ Frame the paper as a formal ablation study   │
│     Engineering"        │ of Oxford's X-Trend, isolating the marginal  │
│                         │ predictive value of order flow vs price.     │
├─────────────────────────┼──────────────────────────────────────────────┤
│ 2. "Single-Asset        │ Run cross-asset transfer tests: pre-train on │
│     Overfitting"        │ BTC and evaluate zero-shot transfer on ETH   │
│                         │ and SOL futures (matching Wood et al.).      │
├─────────────────────────┼──────────────────────────────────────────────┤
│ 3. "Adverse Selection / │ Model adverse selection explicitly: deduct   │
│     Limit Mirage"       │ conservative 1-tick slippage + 0.04% taker   │
│                         │ fee on all market orders; require price to   │
│                         │ penetrate limit levels by >= 1 full tick.    │
├─────────────────────────┼──────────────────────────────────────────────┤
│ 4. "Data Revision /     │ Use strict point-in-time release values from │
│     Lookahead"          │ original historical BLS/Fed release bulletins│
│                         │ with verified zero revision lookahead.       │
├─────────────────────────┼──────────────────────────────────────────────┤
│ 5. "Why Few-Shot?       │ Include full ablation suite: Raw CE,         │
│     Over-Engineering"   │ Logistic Regression, LightGBM, and X-Trend,  │
│                         │ proving statistically where the edge lies.   │
└─────────────────────────┴──────────────────────────────────────────────┘
```
