# Market-Moving News Taxonomy & Dataset Ingestion Architecture

## 1. News Classification Taxonomy

News events affecting financial markets—particularly Bitcoin (BTC) and broader liquid macro assets (Gold/NQ)—fall into five distinct categories based on predictability, transmission mechanism, and volatility duration.

---

### Category 1: Scheduled Tier-1 Macroeconomic Announcements
*Characteristics: High predictability of timing (exact second known in advance), severe 15m volatility spikes, spread blowouts, and order-book liquidity withdrawal.*

- **FOMC Interest Rate Decision & Policy Statement:** The benchmark rate decision by the US Federal Reserve. Dictates global dollar liquidity, borrowing costs, and risk-asset discount rates.
- **FOMC Press Conference (Fed Chair Q&A):** Fed Chair's live speech 30 minutes after rate decisions; causes violent whipsaws based on hawkish vs. dovish phrasing.
- **CPI (Consumer Price Index) & Core PCE:** Primary inflation gauges. Higher-than-expected inflation prompts higher interest rate expectations (bearish for BTC/equities, volatile for Gold).
- **NFP (Non-Farm Payrolls) & Unemployment Rate:** US labor market health. Strong jobs data signals economic resilience but increases Fed hawkishness.
- **GDP (Advance/Second Releases):** National economic growth gauge. Signals expansion vs. recessionary contraction.
- **PPI (Producer Price Index):** Wholesale inflation pipeline leading indicator.

---

### Category 2: Crypto-Specific Regulatory & Institutional Catalyst News
*Characteristics: Semi-scheduled or breaking news that directly alters the legal status, capital access, or regulatory perimeter of Bitcoin.*

- **SEC / CFTC Regulatory Actions & Lawsuits:** Enforcement actions against major exchanges (Binance, Coinbase) or classification rulings on digital assets.
- **Spot ETF Approvals & Net Daily Flows:** Daily net inflows/outflows from institutional spot ETFs (e.g., BlackRock IBIT, Fidelity FBTC). Institutional flow reports release every evening.
- **Sovereign Adoption & Strategic Reserve Legislation:** Bills regarding national Bitcoin reserves or legal tender adoption (e.g., El Salvador, US Strategic Bitcoin Reserve bills).
- **Corporate Treasury Disclosures:** Regular 8-K SEC filings from corporate buyers (e.g., MicroStrategy / Strategy purchases).

---

### Category 3: Systemic Counterparty & Microstructure Shock News
*Characteristics: Unscheduled "Black Swan" events causing severe one-sided liquidation cascades, basis dislocations, and market-maker withdrawals.*

- **Exchange Insolvency, Run, or Legal Seizure:** Historical precedents: Mt. Gox, FTX, Bitfinex. Direct threats to custodial funds and exchange matching engines.
- **Stablecoin Depegging & Reserve Scrutiny:** Runs on major stablecoins (USDT, USDC, UST). Because crypto is priced in USDT/USDC, a stablecoin depeg causes immediate artificial price distortions.
- **Government Seizure Liquidation Transfers:** On-chain movements of seized Bitcoin by sovereign entities (e.g., US Department of Justice Silk Road wallets, German BKA seized coins moving to exchanges).
- **Major Protocol / Bridge Hacks:** Multi-hundred-million-dollar exploits causing contagion.

---

### Category 4: Geopolitical & Macro Risk-Off Shocks
*Characteristics: Asymmetric exogenous shocks impacting global liquidity, commodity prices, and currency valuations.*

- **Military Conflicts & Escalations:** Missile strikes, invasions, or regional war escalations. Often triggers initial liquidity flight into cash/gold and liquidations in high-beta crypto.
- **Trade Sanctions & Tariff Announcements:** Executive orders imposing import tariffs or trade barriers, disrupting global supply chains and currency pegs.
- **Sovereign Debt Downgrades & Banking Panics:** Credit rating agency downgrades (Moody's, S&P) of sovereign debt or regional bank distress (e.g., SVB collapse).

---

### Category 5: Influential Market Commentary & Social Sentiment
*Characteristics: High-frequency narrative shifts driven by prominent market figures or viral retail trends.*

- **Central Bank Speeches (Inter-meeting):** Comments by voting Fed governors (Waller, Bowman, Williams).
- **High-Profile Market Commentators:** Statements from major hedge fund managers, tech executives, or political figures.
- **Viral Social Sentiment Spikes:** Coordinated retail momentum or panic sentiment surges across Twitter/X, Reddit (`r/Bitcoin`, `r/CryptoCurrency`), and Telegram.

---

## 2. Ingestion Strategy & Concrete Datasets (Free & Verified)

To train a Machine Learning model without lookahead bias, news datasets must contain **exact publication timestamps** down to the minute:

### 1. Local US Macroeconomic Calendar (Already Available Locally on Disk)
- **Path:** `/home/rarebat/ict-silver-bullet/data/training/calendar_us_2021_2026.csv`
- **Coverage:** 2021-01-08 to 2026-12-16 (192 clean point-in-time events).
- **Events:** Exact release timestamps for FOMC, CPI, and NFP.
- **Features Generated:**
  - `minutes_to_next_event`: Signed integer representing the distance in minutes to the next high-impact release.
  - `event_risk_zone`: Binary flag (1 if within ±30 minutes of event, 0 otherwise).
  - `event_type`: Categorical one-hot encoding (FOMC, CPI, NFP).

### 2. Alternative.me Crypto Fear & Greed Index (100% Free Public API)
- **Endpoint:** `https://api.alternative.me/fng/?limit=0`
- **Coverage:** Complete daily historical time series from 2018 to present.
- **Fields:**
  - `value`: Daily continuous sentiment score between 0 (Extreme Fear) and 100 (Extreme Greed).
  - `value_classification`: Categorical regime tag.
- **Features Generated:**
  - `fng_score`: Current regime sentiment value.
  - `fng_delta_7d`: 7-day momentum change in market sentiment.

### 3. Federal Reserve Official Public Announcements (Free RSS & XML Feeds)
- **Source:** `federalreserve.gov/feeds/press_monetary.xml`
- **Coverage:** All official monetary policy statements and transcripts.
- **Features Generated:**
  - `fed_statement_word_count`: Length and complexity of the statement.
  - `fed_tone_score`: FinBERT sentiment analysis applied to policy text.

### 4. Natural Language Sentiment Pipelines (Open Source)
- **HuggingFace Hub Datasets:** Pre-scraped historical financial and crypto headline archives (e.g., `financial_phrasebank`, `crypto-news-2020-2025`).
- **Transformer Vectorization:**
  - Model: `ProsusAI/finbert` (local open-source financial sentiment transformer).
  - Output: Continuous probability scores `[negative, neutral, positive]` mapped to a single polarity index $[-1.0, +1.0]$.
