# 30-Day Master Execution & Apprenticeship Plan: Intraday Few-Shot Signal Engine

**Project Working Title:** Few-Shot Trajectory Archetype Prediction in Intraday Bitcoin: Conditioning Trend-Following Metric Networks on Centralized Order Flow and Macroeconomic Catalysts  
**Target Submission:** *The Journal of Financial Data Science* (JFDS) / *Quantitative Finance*  
**Operational Rule:** Strict waterfall progression. No phase may begin until all prerequisite Hard Gates are mathematically verified and signed off.

---

## Plan Overview & Phase Architecture

```
[Phase 1: Days 1–7]   Base Paper Deep Decomposition & Formal Gap Audit
[Phase 2: Days 8–14]  Data Engineering, Pipeline Ingestion & Trajectory Labeling
[Phase 3: Days 15–22] Model Architecture Formulation & Episodic Meta-Training
[Phase 4: Days 23–27] Combinatorial Purged Backtesting & Falsification Rigor
[Phase 5: Days 28–30] Live Execution Engine Harness & Scientific Manuscript Package
```

---

## Phase 1: Base Paper Deep Decomposition & Formal Gap Audit (Days 1 to 7)

### Day 1: Bibliographic Identity & Problem Formulation
- **Core Task:** Conduct line-by-line reading of Wood, Kessler, Roberts, & Zohren (Oxford-Man Institute, *JFDS* 2024, arXiv:2310.10500). Extract Section 1 (Introduction) and Section 2 (Related Work).
- **Methodological Rationale:** Establish the author's exact problem formulation: why stationary deep learning models fail during market regime shifts (e.g., COVID-19 March 2020 crash).
- **Hard Gate 1:** Produce a verified mathematical summary document (`BASE_PAPER_ANALYSIS.md`) detailing the exact equations for daily Sharpe ratio optimization.
- **Apprenticeship Exercise 1:** Why does standard gradient descent on a 3-year historical dataset cause a neural network to take catastrophic loss-making positions during an abrupt regime shift?

### Day 2: The X-Trend Architecture Dissection (Cross-Attention Mechanism)
- **Core Task:** Dissect Section 3 of Wood et al. (The Cross-Attentive Time-Series Trend Network). Map how Query vectors from the current market regime attend over Key/Value pairs from historical context regimes.
- **Methodological Rationale:** Understand why cross-attention over historical regimes preserves knowledge without catastrophic forgetting, unlike standard recurrent architectures (LSTM/GRU).
- **Hard Gate 2:** Implement a standalone PyTorch demonstration of the cross-attention equation:
  $$\text{Attention}(Q, K, V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$$
  Confirm tensor shapes for batch size $B$, sequence length $L$, and feature dimension $D$.
- **Apprenticeship Exercise 2:** Explain how cross-attention differs from standard self-attention when transferring patterns from a past bull market to a current choppy market.

### Day 3: Change-Point Detection (CPD) & Regime Segmentation
- **Core Task:** Study how the base paper splits time series into distinct context regimes using Change-Point Detection (BOCPD - Bayesian Online Change Point Detection).
- **Methodological Rationale:** Regime boundaries cannot be arbitrary calendar months; they must correspond to statistical shifts in return variance and trend drift.
- **Hard Gate 3:** Run a Python CPD baseline script on BTC 2024 data to segment the price series into high-volatility vs. low-volatility regimes.
- **Apprenticeship Exercise 3:** If a change-point algorithm delays detection of a regime shift by 4 bars, what is the impact on model drawdowns?

### Day 4: Baseline Models & Evaluation Metrics in Prior Art
- **Core Task:** Analyze the benchmark baselines used in Wood et al.: Time-Series Momentum (TSMOM), Deep Momentum Networks (DMN), and standard Long Short-Term Memory (LSTM) forecasters.
- **Methodological Rationale:** In Q1 peer review, your model is only as good as the baselines you beat. Understanding their exact hyperparameter tuning prevents strawman comparisons.
- **Hard Gate 4:** Tabulate reported performance metrics from Wood et al. (Sharpe Ratio improvement: +18.9% over neural baselines, 10x over classic TSMOM, 2x faster recovery from drawdown).
- **Apprenticeship Exercise 4:** Why is "Time to Recovery from Drawdown" a more reliable institutional risk metric than raw total cumulative return?

### Day 5: The Three Critical Gaps in Wood et al. (2024)
- **Core Task:** Audit the threats to validity and explicit omissions in the base paper.
- **Methodological Rationale:** This establishes the scientific justification for our paper.
- **The Three Documented Gaps:**
  1. *Microstructure Blindness:* Wood et al. evaluated daily OHLC prices; they had zero access to centralized order-flow delta or liquidity book imbalances.
  2. *Macro Announcement Blindness:* They treated all calendar days uniformly, ignoring scheduled volatility shocks (FOMC, CPI, NFP).
  3. *Unstructured Exit Logic:* They output continuous positions $z_t \in [-1, 1]$ without explicit Risk:Reward barriers or trade invalidation stops.
- **Hard Gate 5:** Formal sign-off on `GAP_AUDIT_MATRIX.md` mapping each limitation of Wood et al. to our proposed technical solution.
- **Apprenticeship Exercise 5:** Why does an algorithm operating on 15m crypto require order flow data, whereas a daily commodity trend-follower can partially survive on pure price returns?

### Day 6: Reformulating X-Trend for 15-Minute Intraday Trajectories
- **Core Task:** Translate the Oxford daily macro framework into our intraday 15m trajectory classification engine.
- **Methodological Rationale:** Bridging daily cross-attention with our Three Trajectory Archetypes (Clean Expansion, Sweep Retest, Collapse).
- **Hard Gate 6:** Write mathematical specification defining the 8-bar trajectory vector $\mathbf{Y}_t = [y_{t+1}, y_{t+2}, \dots, y_{t+8}]$ normalized by $\text{ATR}_{14}$.
- **Apprenticeship Exercise 6:** Why must post-signal price trajectories be normalized by volatility ($\text{ATR}$) before clustering into archetypes?

### Day 7: Phase 1 Review & Preregistration Protocol Sign-off
- **Core Task:** Assemble `PROTOCOL_PREREGISTRATION.md` establishing all hypotheses, baseline comparisons, and statistical significance thresholds ($p < 0.01$).
- **Hard Gate 7:** Formal owner sign-off. Phase 1 complete. Zero code for model training may be written until this protocol is locked.

---

## Phase 2: Data Engineering, Pipeline Ingestion & Trajectory Labeling (Days 8 to 14)

### Day 8: Binance Vision 5-Year Data Ingestion Pipeline
- **Core Task:** Implement automated Python downloader (`download_binance_vision.py`) pulling 60 monthly archives of 15m `BTCUSDT` klines from `data.binance.vision`.
- **Methodological Rationale:** Download pre-aggregated monthly zips rather than making millions of REST API calls; ensures zero rate-limiting and exact reproducibility.
- **Hard Gate 8:** Verify SHA-256 checksums for all downloaded archives against Binance public `.CHECKSUM` files.
- **Apprenticeship Exercise 8:** What is the operational risk of training a trading bot on REST API live-scraped data versus hash-verified historical exchange archives?

### Day 9: Order Flow Feature Engineering (Delta & CVD)
- **Core Task:** Compute true aggressive microstructure features from raw Binance columns:
  - $\text{Taker Buy Vol} = \text{taker\_buy\_volume}$
  - $\text{Taker Sell Vol} = \text{volume} - \text{taker\_buy\_volume}$
  - $\text{Bar Delta} = 2 \times \text{taker\_buy\_volume} - \text{volume}$
  - $\text{CVD}_{4} = \sum_{i=0}^3 \text{Bar Delta}_{t-i}$
- **Methodological Rationale:** Captures aggressive market orders crossing the spread to trade against passive resting limit orders.
- **Hard Gate 9:** Unit tests verifying $\text{Taker Buy} + \text{Taker Sell} = \text{Total Volume}$ for 100% of bars. Zero NaN or infinite values.
- **Apprenticeship Exercise 9:** If a green candle closes near its high but has a negative Bar Delta, what does this indicate about passive limit selling?

### Day 10: Point-in-Time Macro Calendar Clock Integration
- **Core Task:** Ingest `/home/rarebat/ict-silver-bullet/data/training/calendar_us_2021_2026.csv` (192 verified FOMC, CPI, and NFP releases). Compute `minutes_to_next_news` and `news_risk_flag` ($\le 30$ mins) for every 15m timestamp in UTC.
- **Methodological Rationale:** Strictly point-in-time; releases must be timestamped to the exact scheduled second to prevent lookahead leakage.
- **Hard Gate 10:** Verify that every historical FOMC release aligns exactly with its observed volatility spike on the 15m chart.
- **Apprenticeship Exercise 10:** Why does incorporating news release timestamps as a numerical distance feature avoid the natural language processing hallucination trap?

### Day 11: Python Vectorization of Chandelier Exit
- **Core Task:** Vectorize `chandelier_exit.pine` in Python (`src/indicators/chandelier.py`) matching the exact TradingView logic (Length=22, Multiplier=3.0, close-price extremums).
- **Methodological Rationale:** Eliminates bar-by-bar looping; vectorization enables instant computation across 175,000 bars.
- **Hard Gate 11:** 100% parity test: verify that Python signals match TradingView Pine Script signal outputs bar-for-bar on a 500-candle sample.
- **Apprenticeship Exercise 11:** Why does the `useClose=true` parameter in the Chandelier Exit produce fewer false whipsaws than using candle high/low extremums in volatile crypto?

### Day 12: Trajectory Archetype Extraction & Clustering Algorithm
- **Core Task:** For every confirmed Chandelier Exit flip ($t$), extract the next 8 bars ($t+1$ to $t+8$). Cluster them into the three ground-truth classes:
  - Class 1 (Clean Expansion): Hits $+2\text{ATR}$ without retracing $> 0.5\text{ATR}$.
  - Class 2 (Sweep Retest): Retraces to test the CE stop line ($-1\text{ATR}$) before reversing toward $+2\text{ATR}$.
  - Class 3 (Collapse): Penetrates through the stop loss or stagnates below entry.
- **Methodological Rationale:** Converts continuous noisy price paths into discrete, actionable execution archetypes.
- **Hard Gate 12:** Generate distribution report showing class frequencies (e.g., ~25% Clean, ~35% Sweep, ~40% Collapse).
- **Apprenticeship Exercise 12:** Why does separating "Sweep Retests" from "Clean Expansions" prevent premature stop-outs?

### Day 13: Feature Matrix Assembly & Strict Purging
- **Core Task:** Assemble the unified $(X, y)$ dataset: 12 engineered features (Order Flow Delta, CVD momentum, ATR ratios, Macro News Clock, Fear & Greed Index) matched with the ground-truth Trajectory Archetype labels.
- **Methodological Rationale:** Apply Marcos López de Prado's **purging and embargoing** rules: drop all bars where forward label evaluation overlaps with subsequent signal windows.
- **Hard Gate 13:** Check dataset integrity: verify zero label leakage (no feature $X_t$ uses data from $t+1$ or beyond).
- **Apprenticeship Exercise 13:** What is "feature leakage" in financial ML, and why does standard `train_test_split` cause 99% of algorithmic backtests to fail out-of-sample?

### Day 14: Phase 2 Review & Master Dataset Hash Locking
- **Core Task:** Save the master dataset to `/home/rarebat/ResearchStudio/btc-15m-master.parquet`. Calculate and lock its SHA-256 hash in `DATA_MANIFEST.json`.
- **Hard Gate 14:** Phase 2 complete. Master training data is frozen.

---

## Phase 3: Model Architecture Formulation & Episodic Meta-Training (Days 15 to 22)

### Day 15: Prototypical Metric Network Architecture Design
- **Core Task:** Implement the Few-Shot Metric Embedding Network $f_\theta(X)$ in PyTorch (`src/models/prototypical_net.py`).
  - Architecture: 3-layer MLP / 1D-CNN with LayerNorm and Dropout (0.2).
  - Output: 16-dimensional latent embedding vector $\mathbf{z}_t \in \mathbb{R}^{16}$.
- **Methodological Rationale:** Low-dimensional latent embeddings prevent the curse of dimensionality and force the network to discard noise.
- **Hard Gate 15:** Verify forward pass tensor dimensions: input $(B, 12) \to$ output $(B, 16)$.
- **Apprenticeship Exercise 15:** Why is an embedding dimension of 16 superior to an embedding dimension of 512 for a 12-feature financial input matrix?

### Day 16: Episodic Task Generator (Support & Query Splitting)
- **Core Task:** Build the episodic task sampler (`src/data/episodic_sampler.py`). Construct $N$-way $K$-shot episodes ($N=3$ classes, $K=5$ support samples per class, $Q=15$ query samples).
- **Methodological Rationale:** Mimics the meta-learning setup of Snell et al. (NeurIPS) and Wood et al. (2024), enforcing chronological walk-forward episodic sampling.
- **Hard Gate 16:** Confirm that all support sets strictly precede query sets in time within every episode to preserve causality.
- **Apprenticeship Exercise 16:** Explain the difference between "training sample" in standard ML vs. "episode" in Few-Shot Learning.

### Day 17: Class Prototype Computation & Distance Metric
- **Core Task:** Implement prototype calculation:
  $$\mathbf{c}_k = \frac{1}{|S_k|} \sum_{(\mathbf{x}_i, y_i) \in S_k} f_\theta(\mathbf{x}_i)$$
  Compute Euclidean distances $d(\mathbf{z}_q, \mathbf{c}_k)$ and softmax probabilities:
  $$P(y = k \mid \mathbf{x}_q) = \frac{\exp(-d(f_\theta(\mathbf{x}_q), \mathbf{c}_k))}{\sum_{k'} \exp(-d(f_\theta(\mathbf{x}_q), \mathbf{c}_{k'}))}$$
- **Methodological Rationale:** Metric distance provides a bounded, geometric interpretation of pattern similarity.
- **Hard Gate 17:** Mathematical sanity test: verify that when a query sample is identical to prototype $\mathbf{c}_k$, distance is 0 and probability approaches 1.0.
- **Apprenticeship Exercise 17:** Why does Euclidean distance in normalized latent space outperform Cosine similarity when measuring trade setup confidence?

### Day 18: Asymmetric Prop-Firm Barrier Loss Implementation
- **Core Task:** Implement custom loss function (`src/models/losses.py`). Penalize misclassifying a Collapse (Class 3) as a Clean Expansion (Class 1) by $3\times$ higher weight than standard classification error:
  $$\mathcal{L} = -\sum_{k} w_k \cdot y_k \log(\hat{p}_k) + \lambda \cdot \text{DrawdownPenalty}$$
- **Methodological Rationale:** In prop-firm trading, avoiding a catastrophic loss is twice as important as catching an extra winner due to daily drawdown termination limits.
- **Hard Gate 18:** Run gradient test verifying that backward pass propagates correctly through the weighted loss without gradient explosion.
- **Apprenticeship Exercise 18:** Why is traditional symmetric Cross-Entropy loss economically sub-optimal for algorithmic trading systems?

### Day 19: Training Loop & Early Stopping on Validation Episodes
- **Core Task:** Train the meta-network across 1,000 episodes using AdamW optimizer ($\text{lr} = 10^{-3}$, weight decay $= 10^{-4}$). Track validation episodic loss with early stopping (patience = 50 episodes).
- **Methodological Rationale:** Prevents meta-overfitting to specific historical training epochs.
- **Hard Gate 19:** Generate training/validation loss curves. Confirm validation loss reaches stable convergence without divergence.
- **Apprenticeship Exercise 19:** What does an early diverging validation loss curve indicate in episodic few-shot training?

### Day 20: Ablation Model 1 — Standard Static LightGBM Baseline
- **Core Task:** Train an optimized LightGBM classifier on the identical $(X, y)$ dataset without few-shot episodic structure.
- **Methodological Rationale:** Directly measures the performance delta between standard static gradient-boosted trees and our few-shot metric architecture.
- **Hard Gate 20:** Log baseline LightGBM out-of-sample F1-score, precision, and log-loss for all 3 classes.
- **Apprenticeship Exercise 20:** Why is LightGBM the strongest non-neural benchmark for tabular financial data?

### Day 21: Ablation Model 2 — Raw Indicator Baseline (Zero ML)
- **Core Task:** Execute the un-filtered Chandelier Exit strategy across the identical evaluation window (taking every signal blindly at 2:1 R:R).
- **Methodological Rationale:** Establishes the floor baseline: proves conclusively that the raw indicator loses money without the AI filter.
- **Hard Gate 21:** Log raw baseline metrics: Profit Factor, Win Rate, and Maximum Drawdown.
- **Apprenticeship Exercise 21:** If the raw indicator has a 36% win rate at 2:1 R:R, why does it produce a negative expectancy after deducting 0.04% exchange fees?

### Day 22: Phase 3 Review & Model Checkpoint Serialization
- **Core Task:** Serialize trained PyTorch model weights to `/home/rarebat/PORTFOLIO/Signal/GOLD/models/few_shot_engine_v1.pt`. Lock model hash.
- **Hard Gate 22:** Phase 3 complete. Model weights frozen.

---

## Phase 4: Combinatorial Purged Backtesting & Falsification Rigor (Days 23 to 27)

### Day 23: Combinatorial Purged Cross-Validation (CPCV) Implementation
- **Core Task:** Implement Marcos López de Prado's Combinatorial Purged Cross-Validation (`src/evaluation/cpcv.py`) with $N=6$ splits and $k=2$ testing groups (generating $\binom{6}{2} = 15$ distinct out-of-sample backtest paths).
- **Methodological Rationale:** Single-split train/test splits are vulnerable to regime bias. CPCV tests the model across all historical combinations while strictly purging overlapping trade windows.
- **Hard Gate 23:** Verify that zero training data leaks into testing groups across all 15 combinatorial paths.
- **Apprenticeship Exercise 23:** Why does testing across 15 combinatorial backtest paths provide stronger statistical significance than a single walk-forward split?

### Day 24: Realistic Execution Engine (Fee & Slippage Simulation)
- **Core Task:** Run the backtesting engine deducting exact institutional fees:
  - 0.04% Taker fee on market orders (Clean Expansion entries).
  - 0.02% Maker fee on passive limit orders (Sweep Retest fills).
  - 1 tick ($0.50 on BTC) simulated slippage on all stop-loss exits.
- **Methodological Rationale:** Converts theoretical paper alpha into verifiable live-trading profitability.
- **Hard Gate 24:** Verify that net PnL remains positive after deducting cumulative fee drag across 1,000+ trades.
- **Apprenticeship Exercise 24:** How does a high trade frequency (e.g., 20 trades/day) destroy a trading bot's edge even if the win rate is 55%?

### Day 25: Verification Against Hard KPI Contract
- **Core Task:** Measure out-of-sample performance across all 15 CPCV paths against our pre-registered KPIs:
  - KPI 1: Profit Factor $\ge 1.60$.
  - KPI 2: Win Rate at 2:1 R:R $\ge 45.0\%$.
  - KPI 3: Maximum Peak-to-Trough Drawdown $\le 4.0\%$.
  - KPI 4: Trade Abstention Ratio $\ge 50\%$.
- **Hard Gate 25:** If any KPI fails to meet the pre-registered threshold, immediately trigger Root Cause Audit protocol (document why the hypothesis failed without p-hacking).
- **Apprenticeship Exercise 25:** Why is publishing an honest, rigorously documented negative result superior to tweaking parameters post-hoc to fake a backtest?

### Day 26: Deflated Sharpe Ratio & White's Reality Check
- **Core Task:** Compute the Deflated Sharpe Ratio (DSR) using Bailey & López de Prado (2014) to adjust for the number of feature and model configurations tested.
- **Methodological Rationale:** Mathematically disproves that our backtest results are a statistical fluke of data-snooping.
- **Hard Gate 26:** DSR must achieve statistical significance at $p < 0.01$.
- **Apprenticeship Exercise 26:** Explain how the Deflated Sharpe Ratio discounts a strategy's reported Sharpe ratio if the researcher tested 100 variations versus 5 variations.

### Day 27: Synthetic Target Shuffling Falsification Test
- **Core Task:** Permute (randomly shuffle) the target trajectory labels while keeping the feature matrix identical. Re-run the entire training and backtest pipeline 100 times.
- **Methodological Rationale:** If the model still reports a positive Sharpe ratio on scrambled labels, the backtesting harness has lookahead leakage. On scrambled data, Sharpe ratio must collapse to $\le 0.0$.
- **Hard Gate 27:** Confirm synthetic noise distribution centers exactly at Sharpe $\approx 0.0$ ($p > 0.50$). Phase 4 complete.

---

## Phase 5: Live Execution Engine Harness & Scientific Manuscript Package (Days 28 to 30)

### Day 28: Live WebSocket Execution Runner & Latency Audit
- **Core Task:** Build the real-time execution runner (`src/execution/live_runner.py`):
  - Ingests live 15m candle close events from Binance Futures WebSocket.
  - Computes indicator flip and order flow delta in Python memory.
  - Runs forward inference through PyTorch model checkpoint.
  - Places simulated or live testnet order.
- **Methodological Rationale:** Ensures the entire signal-to-order pipeline executes within the millisecond boundary before the next candle advances.
- **Hard Gate 28:** Measure total execution latency from WebSocket message arrival to order emission: must be strictly $< 100\text{ ms}$.
- **Apprenticeship Exercise 28:** What is "adverse selection" when an algorithmic trading bot takes more than 500ms to execute an intraday market order?

### Day 29: Fail-Safe Watchdog & Risk Management Circuit Breakers
- **Core Task:** Implement automated safety guardrails:
  - Daily Loss Circuit Breaker: Auto-kill bot if daily realized loss hits $-2.5\%$.
  - Data Disconnect Watchdog: Auto-cancel all resting limit orders if WebSocket connection drops for $> 10$ seconds.
  - Fallback Mode: Revert strictly to pure Chandelier stop-loss management if ML inference fails.
- **Hard Gate 29:** Execute automated chaos-test: simulate network disconnect during an active trade and verify that stop-loss orders remain active on exchange servers.
- **Apprenticeship Exercise 29:** Why must all stop-loss orders be resting server-side with the exchange rather than held only in local bot memory?

### Day 30: Scientific Manuscript Packaging for Q1 Submission
- **Core Task:** Compile the final academic manuscript (`MANUSCRIPT_DRAFT.tex` / `.md`) following *The Journal of Financial Data Science* author guidelines:
  - Abstract, Introduction & Literature Review (Wood et al., Hasbrouck, de Prado).
  - Mathematical Methodology & Few-Shot Architecture.
  - Data Provenance & Order Flow Feature Engineering.
  - Empirical Results, Baselines & Ablation Tables.
  - Threats to Validity & Reproducibility Appendix (with GitHub code repository link and hash-locked data manifests).
- **Hard Gate 30:** Final Project Sign-Off. 30-Day Research Plan Successfully Completed. Both the Q1 manuscript and the live trading bot are fully realized.

---

## Master Commitment & Non-Deviation Rule

By signing below, the Principal Investigator and Mentor commit to following this 30-Day schedule strictly in sequence. No code from a future day may be written until the current day's Hard Gate has been mathematically verified and documented.

**Principal Investigator:** Arifin Nabid  
**Research Mentor:** Research Apprenticeship Mentor & Systems Researcher  
**Execution Repository:** `/home/rarebat/PORTFOLIO/Signal/GOLD`  
**Research Archive:** `/home/rarebat/ResearchStudio`
