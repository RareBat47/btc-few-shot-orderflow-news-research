# Binance Vision Data Catalog & Meta-Labeling Base Paper Specification

## 1. Project Objective & Architecture
- **Primary Engine:** Chandelier Exit (ATR-based trailing stop & regime detector on 15m timeframe).
- **Core Problem:** ATR-based breakout/trend systems suffer from false positives and whipsaws in choppy or adverse market regimes.
- **Solution Strategy:** Implement **Meta-Labeling** (Two-Tier Model). The primary rule-based engine generates candidate entry signals (Direction $+1$ or $-1$), while a secondary Machine Learning model (XGBoost / LightGBM) predicts the **probability of signal success** based on environmental features (Order Flow + Positioning + News Sentiment).

---

## 2. Binance Public Data Vision (`data.binance.vision`) Inventory

All data below is freely available for **USDT-Margined Futures (`BTCUSDT`)** under `data/futures/um/{monthly,daily}/{data_type}/BTCUSDT/`.

### 1. `klines` (1m, 3m, 5m, 15m, 1h, etc.)
- **Description:** Candlestick bars including `open_time`, `open`, `high`, `low`, `close`, `volume`, `close_time`, `quote_volume`, `count` (trade frequency), `taker_buy_volume`, and `taker_buy_quote_volume`.
- **Project Role:** 
  - Substrate for the primary 15m Chandelier Exit engine.
  - Generates immediate bar-level aggressive order flow:
    - $\text{Aggressive Buy Vol} = \text{taker\_buy\_volume}$
    - $\text{Aggressive Sell Vol} = \text{volume} - \text{taker\_buy\_volume}$
    - $\text{Bar Delta} = 2 \times \text{taker\_buy\_volume} - \text{volume}$

### 2. `metrics` (Daily / 5-Minute Aggregated Market Intelligence)
- **Description:** Institutional and retail positioning indicators published daily:
  - `sum_open_interest` & `sum_open_interest_value`: Total outstanding contract exposure.
  - `top_trader_long_short_ratio` (Accounts & Positions): Ratio of long vs. short positions held by elite institutional accounts.
  - `long_short_ratio`: Global account long/short sentiment (predominantly retail).
  - `taker_long_short_vol_ratio`: Ratio of market buy volume to market sell volume.
- **Project Role:** **Critical Environmental Filter.** Distinguishes between high-conviction institutional breakouts (price rising + OI expanding + elite trader long ratio high) and fake retail breakouts (price rising into resistance + retail heavily long + OI declining / short covering).

### 3. `aggTrades` (Aggregate Trades)
- **Description:** Continuous trade tape where fills at the identical millisecond and price are grouped. Columns: `aggregate_trade_id`, `price`, `quantity`, `first_trade_id`, `last_trade_id`, `timestamp`, `is_buyer_maker`.
- **Project Role:** High-frequency order flow engine. Used to construct intra-candle Cumulative Volume Delta (CVD) and identify volume absorption at swing highs/lows.

### 4. `bookTicker` (Top of Book Best Bid & Ask)
- **Description:** Millisecond timestamps with best bid price, bid quantity, best ask price, and ask quantity.
- **Project Role:** Real-time spread dynamics and liquidity thickness. Detects liquidity drying up or spread blowouts before high-impact news.

### 5. `premiumIndexKlines`
- **Description:** Klines for the Futures Premium Index used to calculate the 8-hour funding rate.
- **Project Role:** Quantifies speculative leverage imbalance. Elevated positive funding flags over-leveraged longs susceptible to rapid cascade liquidations; negative funding flags short squeezes.

### 6. `markPriceKlines` & `indexPriceKlines`
- **Description:** Spot index price and derivatives mark price.
- **Project Role:** Calculates the spot-futures basis (`Basis = Mark Price - Index Price`). Unlocks divergence features where futures aggressively lead spot or vice versa.

### 7. `trades` & `bookDepth`
- **Description:** Unaggregated raw tick trades and multi-level depth snapshots.
- **Project Role:** Secondary / optional. `aggTrades` is preferred over `trades` for 99% of order flow tasks due to 5x faster processing and identical net delta.

---

## 3. The Foundational Base Paper: Meta-Labeling

### Primary Theoretical Reference
- **Author:** Marcos López de Prado (2018)
- **Book / Publication:** *Advances in Financial Machine Learning*, Chapter 3: "Meta-Labeling" & "The Triple-Barrier Method" (John Wiley & Sons, ISBN: 978-1-119-48208-6).
- **SSRN Working Paper:** López de Prado, M. (2018). *"The 10 Applied ML Algorithms Every Quant Should Know"*, DOI: `10.2139/ssrn.3607074`.

### Empirical Peer-Reviewed Prior Art
- **Title:** *"Evaluating Interpretable Meta-Labeling for Intraday Futures Trend Following: Open-Interest Features and Contract-Dependent Outcomes"* (2026).
- **DOI:** `10.2139/ssrn.7356724`.
- **Key Finding:** Applying meta-labeling with Open Interest and order flow features to a trend-following rule improves Sharpe ratio by over 40% and reduces maximum drawdown by filtering out regime-incompatible trades.

---

## 4. Mathematical Implementation for This Project

### Step 1: Primary Model (Deterministic Heuristic)
Run the Chandelier Exit script on 15m `BTCUSDT` klines:
$$\text{dir}_t \in \{-1, +1\}$$
An entry signal $s_t \in \{-1, +1\}$ is triggered when $\text{dir}_t \neq \text{dir}_{t-1}$.

### Step 2: The Triple-Barrier Labeling ($y$)
For each signal at time $t$ with entry price $P_t$ and volatility $\sigma_t = \text{ATR}(14)$:
- **Upper Barrier (TP):** $P_t + (2 \times \sigma_t)$ for long ($P_t - 2\sigma_t$ for short)
- **Lower Barrier (SL):** $P_t - (1 \times \sigma_t)$ for long ($P_t + 1\sigma_t$ for short)
- **Horizontal Barrier (Time Limit):** $t + 16$ bars (4 hours)
- **Label Assignment:**
  $$y_t = \begin{cases} 1 & \text{if price touches TP barrier before SL barrier} \\ 0 & \text{if price touches SL barrier or expires below hurdle} \end{cases}$$

### Step 3: Secondary Model Feature Matrix ($X$)
For each trade opportunity at bar $t$, construct feature vector $X_t$:
1. **Order Flow Features:**
   - Bar Delta: $\text{Delta}_t$
   - 4-bar Cumulative Delta: $\text{CVD}_{4, t}$
   - Taker Buy Ratio: $\frac{\text{taker\_buy\_volume}_t}{\text{volume}_t}$
2. **Binance Environmental Metrics:**
   - 24h Change in Open Interest: $\Delta \text{OI}_{24h}$
   - Top Trader Long/Short Ratio: $\text{TopTraders}_{L/S}$
   - Retail Long/Short Imbalance: $\text{Global}_{L/S}$
   - Premium Index / Funding Rate proxy
3. **Macro / News Sentiment:**
   - FinBERT / GDELT Sentiment Score: $S_t \in [-1.0, +1.0]$
   - Time to next high-impact event (FOMC, CPI) in minutes

### Step 4: The Meta-Predictor
Train a binary classifier $M(X)$:
$$\hat{p}_t = P(y_t = 1 \mid X_t)$$
**Live Execution Rule:**
$$\text{Action} = \begin{cases} \text{Execute Trade } s_t & \text{if } \hat{p}_t \ge \tau \quad (\text{e.g., } \tau = 0.65) \\ \text{Skip / Pass} & \text{if } \hat{p}_t < \tau \end{cases}$$
