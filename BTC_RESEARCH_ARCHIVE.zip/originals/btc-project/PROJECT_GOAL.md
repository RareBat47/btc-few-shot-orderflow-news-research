# Project Goal Charter: Trajectory-Conditioned Few-Shot Signal Engine

## 1. Unified Mission Statement
To design, validate, and deploy a mathematically robust 15-minute trading bot that turns an ATR-based trend heuristic (Chandelier Exit) into an institutional-grade, high Risk:Reward strategy by using **Few-Shot Metric Learning** to classify post-signal price trajectories conditioned on **centralized order flow** and **scheduled macroeconomic announcements**.

---

## 2. The Two Concrete Goals

### Goal A: The Quantitative Research Goal (Q1 Scientific Manuscript)
- **Title:** *Few-Shot Trajectory Archetype Prediction in Intraday Bitcoin: Conditioning Trend-Following Metric Networks on Centralized Order Flow and Macroeconomic Catalysts.*
- **Hypothesis:** Augmenting a trend-following heuristic with Few-Shot Metric Prototypes (trained on Taker Order Flow Delta, CVD, and Macroeconomic Release Proximity) achieves a statistically significant improvement in precision, Sharpe ratio, and tail-drawdown reduction compared to static deep learning baselines and raw indicator execution.
- **Target Journal:** *The Journal of Financial Data Science* (Oxford-Man benchmark extension) or *Quantitative Finance*.

### Goal B: The Practical Engineering & Bot Goal (Live Execution & Prop-Firm Deployment)
- **The Engine:** A fully automated Python engine executing on 15m `BTCUSDT` (and adaptable to Gold/NQ).
- **Execution Mechanism:**
  1. Chandelier Exit detects trend state shift ($+1$ or $-1$).
  2. Few-Shot Metric Engine inspects preceding 5-bar order flow + macro calendar clock.
  3. Classifies subsequent 8-bar trajectory into one of three archetypes:
     - **Clean Expansion:** Immediate execution at market with 2:1 R:R.
     - **Deep Sweep / Retest:** Cancel market order; place a limit order at the CE stop level to buy the retail liquidation sweep.
     - **Mean-Reversion Collapse:** Complete trade abstention (0 risk).

---

## 3. Quantitative Key Performance Indicators (KPIs)

To declare the research and trading bot successful, the system must achieve the following benchmark thresholds out-of-sample under realistic exchange fees (0.04% taker / 0.02% maker) and 1-tick slippage:

- **Profit Factor (PF):** $\ge 1.60$ (Baseline un-filtered Chandelier Exit is typically $< 0.95$).
- **Win Rate at 2:1 Risk-to-Reward:** $\ge 45\%$ (Break-even at 2:1 is 33.4%; 45% yields an institutional edge).
- **Maximum Drawdown (MDD):** $\le 4.0\%$ peak-to-trough (to pass prop-firm daily and total loss constraints).
- **Deflated Sharpe Ratio (DSR):** Statistically significant at $p < 0.01$ after multiple testing corrections.
- **Trade Abstention Rate:** Successfully filter out $\ge 50\%$ of false breakout chops emitted by the raw indicator.
